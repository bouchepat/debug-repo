(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"orgztion:meteor-global-tether":{"Tether.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/orgztion_meteor-global-tether/Tether.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
let Tether;
module.watch(require("tether"), {
  default(v) {
    Tether = v;
  }

}, 0);
global.Tether = Tether;
///////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("./node_modules/meteor/orgztion:meteor-global-tether/Tether.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['orgztion:meteor-global-tether'] = exports;

})();

//# sourceURL=meteor://💻app/packages/orgztion_meteor-global-tether.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3JnenRpb246bWV0ZW9yLWdsb2JhbC10ZXRoZXIvVGV0aGVyLmpzIl0sIm5hbWVzIjpbIlRldGhlciIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwiZ2xvYmFsIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDTCxhQUFPSyxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQ1hDLE9BQU9OLE1BQVAsR0FBZ0JBLE1BQWhCLEMiLCJmaWxlIjoiL3BhY2thZ2VzL29yZ3p0aW9uX21ldGVvci1nbG9iYWwtdGV0aGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFRldGhlciBmcm9tICd0ZXRoZXInXG5nbG9iYWwuVGV0aGVyID0gVGV0aGVyO1xuIl19

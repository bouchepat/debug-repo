(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['poorvavyas:es6-shim'] = {};

})();

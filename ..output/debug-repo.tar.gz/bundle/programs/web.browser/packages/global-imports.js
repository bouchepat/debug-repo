/* Imports for global scope */

Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Roles = Package['alanning:roles'].Roles;
ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
HTTP = Package.http.HTTP;
Session = Package.session.Session;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
Promise = Package.promise.Promise;
Accounts = Package['accounts-base'].Accounts;
Autoupdate = Package.autoupdate.Autoupdate;
Reload = Package.reload.Reload;
Symbol = Package['ecmascript-runtime-client'].Symbol;
Map = Package['ecmascript-runtime-client'].Map;
Set = Package['ecmascript-runtime-client'].Set;


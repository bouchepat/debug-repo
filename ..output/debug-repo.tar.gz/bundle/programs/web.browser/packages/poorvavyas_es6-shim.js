//////////////////////////////////////////////////////////////////////////
//                                                                      //
// This is a generated file. You can view the original                  //
// source in your browser if your browser supports source maps.         //
// Source maps are supported by all recent versions of Chrome, Safari,  //
// and Firefox, and by Internet Explorer 11.                            //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Promise;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/poorvavyas_es6-shim/es6-shim.js                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
 /*!                                                                                                                // 1
  * https://github.com/paulmillr/es6-shim                                                                           // 2
  * @license es6-shim Copyright 2013-2014 by Paul Miller (http://paulmillr.com)                                     // 3
  *   and contributors,  MIT License                                                                                // 4
  * es6-shim: v0.21.1                                                                                               // 5
  * see https://github.com/paulmillr/es6-shim/blob/master/LICENSE                                                   // 6
  * Details and documentation:                                                                                      // 7
  * https://github.com/paulmillr/es6-shim/                                                                          // 8
  */                                                                                                                // 9
                                                                                                                    // 10
// UMD (Universal Module Definition)                                                                                // 11
// see https://github.com/umdjs/umd/blob/master/returnExports.js                                                    // 12
(function (root, factory) {                                                                                         // 13
  if (typeof define === 'function' && define.amd) {                                                                 // 14
    // AMD. Register as an anonymous module.                                                                        // 15
    define(factory);                                                                                                // 16
  } else if (typeof exports === 'object') {                                                                         // 17
    // Node. Does not work with strict CommonJS, but                                                                // 18
    // only CommonJS-like enviroments that support module.exports,                                                  // 19
    // like Node.                                                                                                   // 20
    module.exports = factory();                                                                                     // 21
  } else {                                                                                                          // 22
    // Browser globals (root is window)                                                                             // 23
    root.returnExports = factory();                                                                                 // 24
  }                                                                                                                 // 25
}(this, function () {                                                                                               // 26
  'use strict';                                                                                                     // 27
                                                                                                                    // 28
  var isCallableWithoutNew = function (func) {                                                                      // 29
    try { func(); }                                                                                                 // 30
    catch (e) { return false; }                                                                                     // 31
    return true;                                                                                                    // 32
  };                                                                                                                // 33
                                                                                                                    // 34
  var supportsSubclassing = function (C, f) {                                                                       // 35
    /* jshint proto:true */                                                                                         // 36
    try {                                                                                                           // 37
      var Sub = function () { C.apply(this, arguments); };                                                          // 38
      if (!Sub.__proto__) { return false; /* skip test on IE < 11 */ }                                              // 39
      Object.setPrototypeOf(Sub, C);                                                                                // 40
      Sub.prototype = Object.create(C.prototype, {                                                                  // 41
        constructor: { value: C }                                                                                   // 42
      });                                                                                                           // 43
      return f(Sub);                                                                                                // 44
    } catch (e) {                                                                                                   // 45
      return false;                                                                                                 // 46
    }                                                                                                               // 47
  };                                                                                                                // 48
                                                                                                                    // 49
  var arePropertyDescriptorsSupported = function () {                                                               // 50
    try {                                                                                                           // 51
      Object.defineProperty({}, 'x', {});                                                                           // 52
      return true;                                                                                                  // 53
    } catch (e) { /* this is IE 8. */                                                                               // 54
      return false;                                                                                                 // 55
    }                                                                                                               // 56
  };                                                                                                                // 57
                                                                                                                    // 58
  var startsWithRejectsRegex = function () {                                                                        // 59
    var rejectsRegex = false;                                                                                       // 60
    if (String.prototype.startsWith) {                                                                              // 61
      try {                                                                                                         // 62
        '/a/'.startsWith(/a/);                                                                                      // 63
      } catch (e) { /* this is spec compliant */                                                                    // 64
        rejectsRegex = true;                                                                                        // 65
      }                                                                                                             // 66
    }                                                                                                               // 67
    return rejectsRegex;                                                                                            // 68
  };                                                                                                                // 69
                                                                                                                    // 70
  /*jshint evil: true */                                                                                            // 71
  var getGlobal = new Function('return this;');                                                                     // 72
  /*jshint evil: false */                                                                                           // 73
                                                                                                                    // 74
  var globals = getGlobal();                                                                                        // 75
  var global_isFinite = globals.isFinite;                                                                           // 76
  var supportsDescriptors = !!Object.defineProperty && arePropertyDescriptorsSupported();                           // 77
  var startsWithIsCompliant = startsWithRejectsRegex();                                                             // 78
  var _slice = Array.prototype.slice;                                                                               // 79
  var _indexOf = Function.call.bind(String.prototype.indexOf);                                                      // 80
  var _toString = Function.call.bind(Object.prototype.toString);                                                    // 81
  var _hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);                                        // 82
  var ArrayIterator; // make our implementation private                                                             // 83
                                                                                                                    // 84
  var Symbol = globals.Symbol || {};                                                                                // 85
  var Type = {                                                                                                      // 86
    string: function (x) { return _toString(x) === '[object String]'; },                                            // 87
    regex: function (x) { return _toString(x) === '[object RegExp]'; },                                             // 88
    symbol: function (x) {                                                                                          // 89
      /*jshint notypeof: true */                                                                                    // 90
      return typeof globals.Symbol === 'function' && typeof x === 'symbol';                                         // 91
      /*jshint notypeof: false */                                                                                   // 92
    }                                                                                                               // 93
  };                                                                                                                // 94
                                                                                                                    // 95
  var defineProperty = function (object, name, value, force) {                                                      // 96
    if (!force && name in object) { return; }                                                                       // 97
    if (supportsDescriptors) {                                                                                      // 98
      Object.defineProperty(object, name, {                                                                         // 99
        configurable: true,                                                                                         // 100
        enumerable: false,                                                                                          // 101
        writable: true,                                                                                             // 102
        value: value                                                                                                // 103
      });                                                                                                           // 104
    } else {                                                                                                        // 105
      object[name] = value;                                                                                         // 106
    }                                                                                                               // 107
  };                                                                                                                // 108
                                                                                                                    // 109
  // Define configurable, writable and non-enumerable props                                                         // 110
  // if they don’t exist.                                                                                           // 111
  var defineProperties = function (object, map) {                                                                   // 112
    Object.keys(map).forEach(function (name) {                                                                      // 113
      var method = map[name];                                                                                       // 114
      defineProperty(object, name, method, false);                                                                  // 115
    });                                                                                                             // 116
  };                                                                                                                // 117
                                                                                                                    // 118
  // Simple shim for Object.create on ES3 browsers                                                                  // 119
  // (unlike real shim, no attempt to support `prototype === null`)                                                 // 120
  var create = Object.create || function (prototype, properties) {                                                  // 121
    function Type() {}                                                                                              // 122
    Type.prototype = prototype;                                                                                     // 123
    var object = new Type();                                                                                        // 124
    if (typeof properties !== 'undefined') {                                                                        // 125
      defineProperties(object, properties);                                                                         // 126
    }                                                                                                               // 127
    return object;                                                                                                  // 128
  };                                                                                                                // 129
                                                                                                                    // 130
  // This is a private name in the es6 spec, equal to '[Symbol.iterator]'                                           // 131
  // we're going to use an arbitrary _-prefixed name to make our shims                                              // 132
  // work properly with each other, even though we don't have full Iterator                                         // 133
  // support.  That is, `Array.from(map.keys())` will work, but we don't                                            // 134
  // pretend to export a "real" Iterator interface.                                                                 // 135
  var $iterator$ = Type.symbol(Symbol.iterator) ? Symbol.iterator : '_es6-shim iterator_';                          // 136
  // Firefox ships a partial implementation using the name @@iterator.                                              // 137
  // https://bugzilla.mozilla.org/show_bug.cgi?id=907077#c14                                                        // 138
  // So use that name if we detect it.                                                                              // 139
  if (globals.Set && typeof new globals.Set()['@@iterator'] === 'function') {                                       // 140
    $iterator$ = '@@iterator';                                                                                      // 141
  }                                                                                                                 // 142
  var addIterator = function (prototype, impl) {                                                                    // 143
    if (!impl) { impl = function iterator() { return this; }; }                                                     // 144
    var o = {};                                                                                                     // 145
    o[$iterator$] = impl;                                                                                           // 146
    defineProperties(prototype, o);                                                                                 // 147
    if (!prototype[$iterator$] && Type.symbol($iterator$)) {                                                        // 148
      // implementations are buggy when $iterator$ is a Symbol                                                      // 149
      prototype[$iterator$] = impl;                                                                                 // 150
    }                                                                                                               // 151
  };                                                                                                                // 152
                                                                                                                    // 153
  // taken directly from https://github.com/ljharb/is-arguments/blob/master/index.js                                // 154
  // can be replaced with require('is-arguments') if we ever use a build process instead                            // 155
  var isArguments = function isArguments(value) {                                                                   // 156
    var str = _toString(value);                                                                                     // 157
    var result = str === '[object Arguments]';                                                                      // 158
    if (!result) {                                                                                                  // 159
      result = str !== '[object Array]' &&                                                                          // 160
        value !== null &&                                                                                           // 161
        typeof value === 'object' &&                                                                                // 162
        typeof value.length === 'number' &&                                                                         // 163
        value.length >= 0 &&                                                                                        // 164
        _toString(value.callee) === '[object Function]';                                                            // 165
    }                                                                                                               // 166
    return result;                                                                                                  // 167
  };                                                                                                                // 168
                                                                                                                    // 169
  var emulateES6construct = function (o) {                                                                          // 170
    if (!ES.TypeIsObject(o)) { throw new TypeError('bad object'); }                                                 // 171
    // es5 approximation to es6 subclass semantics: in es6, 'new Foo'                                               // 172
    // would invoke Foo.@@create to allocation/initialize the new object.                                           // 173
    // In es5 we just get the plain object.  So if we detect an                                                     // 174
    // uninitialized object, invoke o.constructor.@@create                                                          // 175
    if (!o._es6construct) {                                                                                         // 176
      if (o.constructor && ES.IsCallable(o.constructor['@@create'])) {                                              // 177
        o = o.constructor['@@create'](o);                                                                           // 178
      }                                                                                                             // 179
      defineProperties(o, { _es6construct: true });                                                                 // 180
    }                                                                                                               // 181
    return o;                                                                                                       // 182
  };                                                                                                                // 183
                                                                                                                    // 184
  var ES = {                                                                                                        // 185
    CheckObjectCoercible: function (x, optMessage) {                                                                // 186
      /* jshint eqnull:true */                                                                                      // 187
      if (x == null) {                                                                                              // 188
        throw new TypeError(optMessage || 'Cannot call method on ' + x);                                            // 189
      }                                                                                                             // 190
      return x;                                                                                                     // 191
    },                                                                                                              // 192
                                                                                                                    // 193
    TypeIsObject: function (x) {                                                                                    // 194
      /* jshint eqnull:true */                                                                                      // 195
      // this is expensive when it returns false; use this function                                                 // 196
      // when you expect it to return true in the common case.                                                      // 197
      return x != null && Object(x) === x;                                                                          // 198
    },                                                                                                              // 199
                                                                                                                    // 200
    ToObject: function (o, optMessage) {                                                                            // 201
      return Object(ES.CheckObjectCoercible(o, optMessage));                                                        // 202
    },                                                                                                              // 203
                                                                                                                    // 204
    IsCallable: function (x) {                                                                                      // 205
      return typeof x === 'function' &&                                                                             // 206
        // some versions of IE say that typeof /abc/ === 'function'                                                 // 207
        _toString(x) === '[object Function]';                                                                       // 208
    },                                                                                                              // 209
                                                                                                                    // 210
    ToInt32: function (x) {                                                                                         // 211
      return x >> 0;                                                                                                // 212
    },                                                                                                              // 213
                                                                                                                    // 214
    ToUint32: function (x) {                                                                                        // 215
      return x >>> 0;                                                                                               // 216
    },                                                                                                              // 217
                                                                                                                    // 218
    ToInteger: function (value) {                                                                                   // 219
      var number = +value;                                                                                          // 220
      if (Number.isNaN(number)) { return 0; }                                                                       // 221
      if (number === 0 || !Number.isFinite(number)) { return number; }                                              // 222
      return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));                                                  // 223
    },                                                                                                              // 224
                                                                                                                    // 225
    ToLength: function (value) {                                                                                    // 226
      var len = ES.ToInteger(value);                                                                                // 227
      if (len <= 0) { return 0; } // includes converting -0 to +0                                                   // 228
      if (len > Number.MAX_SAFE_INTEGER) { return Number.MAX_SAFE_INTEGER; }                                        // 229
      return len;                                                                                                   // 230
    },                                                                                                              // 231
                                                                                                                    // 232
    SameValue: function (a, b) {                                                                                    // 233
      if (a === b) {                                                                                                // 234
        // 0 === -0, but they are not identical.                                                                    // 235
        if (a === 0) { return 1 / a === 1 / b; }                                                                    // 236
        return true;                                                                                                // 237
      }                                                                                                             // 238
      return Number.isNaN(a) && Number.isNaN(b);                                                                    // 239
    },                                                                                                              // 240
                                                                                                                    // 241
    SameValueZero: function (a, b) {                                                                                // 242
      // same as SameValue except for SameValueZero(+0, -0) == true                                                 // 243
      return (a === b) || (Number.isNaN(a) && Number.isNaN(b));                                                     // 244
    },                                                                                                              // 245
                                                                                                                    // 246
    IsIterable: function (o) {                                                                                      // 247
      return ES.TypeIsObject(o) &&                                                                                  // 248
        (typeof o[$iterator$] !== 'undefined' || isArguments(o));                                                   // 249
    },                                                                                                              // 250
                                                                                                                    // 251
    GetIterator: function (o) {                                                                                     // 252
      if (isArguments(o)) {                                                                                         // 253
        // special case support for `arguments`                                                                     // 254
        return new ArrayIterator(o, 'value');                                                                       // 255
      }                                                                                                             // 256
      var itFn = o[$iterator$];                                                                                     // 257
      if (!ES.IsCallable(itFn)) {                                                                                   // 258
        throw new TypeError('value is not an iterable');                                                            // 259
      }                                                                                                             // 260
      var it = itFn.call(o);                                                                                        // 261
      if (!ES.TypeIsObject(it)) {                                                                                   // 262
        throw new TypeError('bad iterator');                                                                        // 263
      }                                                                                                             // 264
      return it;                                                                                                    // 265
    },                                                                                                              // 266
                                                                                                                    // 267
    IteratorNext: function (it) {                                                                                   // 268
      var result = arguments.length > 1 ? it.next(arguments[1]) : it.next();                                        // 269
      if (!ES.TypeIsObject(result)) {                                                                               // 270
        throw new TypeError('bad iterator');                                                                        // 271
      }                                                                                                             // 272
      return result;                                                                                                // 273
    },                                                                                                              // 274
                                                                                                                    // 275
    Construct: function (C, args) {                                                                                 // 276
      // CreateFromConstructor                                                                                      // 277
      var obj;                                                                                                      // 278
      if (ES.IsCallable(C['@@create'])) {                                                                           // 279
        obj = C['@@create']();                                                                                      // 280
      } else {                                                                                                      // 281
        // OrdinaryCreateFromConstructor                                                                            // 282
        obj = create(C.prototype || null);                                                                          // 283
      }                                                                                                             // 284
      // Mark that we've used the es6 construct path                                                                // 285
      // (see emulateES6construct)                                                                                  // 286
      defineProperties(obj, { _es6construct: true });                                                               // 287
      // Call the constructor.                                                                                      // 288
      var result = C.apply(obj, args);                                                                              // 289
      return ES.TypeIsObject(result) ? result : obj;                                                                // 290
    }                                                                                                               // 291
  };                                                                                                                // 292
                                                                                                                    // 293
  var numberConversion = (function () {                                                                             // 294
    // from https://github.com/inexorabletash/polyfill/blob/master/typedarray.js#L176-L266                          // 295
    // with permission and license, per https://twitter.com/inexorabletash/status/372206509540659200                // 296
                                                                                                                    // 297
    function roundToEven(n) {                                                                                       // 298
      var w = Math.floor(n), f = n - w;                                                                             // 299
      if (f < 0.5) {                                                                                                // 300
        return w;                                                                                                   // 301
      }                                                                                                             // 302
      if (f > 0.5) {                                                                                                // 303
        return w + 1;                                                                                               // 304
      }                                                                                                             // 305
      return w % 2 ? w + 1 : w;                                                                                     // 306
    }                                                                                                               // 307
                                                                                                                    // 308
    function packIEEE754(v, ebits, fbits) {                                                                         // 309
      var bias = (1 << (ebits - 1)) - 1,                                                                            // 310
        s, e, f,                                                                                                    // 311
        i, bits, str, bytes;                                                                                        // 312
                                                                                                                    // 313
      // Compute sign, exponent, fraction                                                                           // 314
      if (v !== v) {                                                                                                // 315
        // NaN                                                                                                      // 316
        // http://dev.w3.org/2006/webapi/WebIDL/#es-type-mapping                                                    // 317
        e = (1 << ebits) - 1;                                                                                       // 318
        f = Math.pow(2, fbits - 1);                                                                                 // 319
        s = 0;                                                                                                      // 320
      } else if (v === Infinity || v === -Infinity) {                                                               // 321
        e = (1 << ebits) - 1;                                                                                       // 322
        f = 0;                                                                                                      // 323
        s = (v < 0) ? 1 : 0;                                                                                        // 324
      } else if (v === 0) {                                                                                         // 325
        e = 0;                                                                                                      // 326
        f = 0;                                                                                                      // 327
        s = (1 / v === -Infinity) ? 1 : 0;                                                                          // 328
      } else {                                                                                                      // 329
        s = v < 0;                                                                                                  // 330
        v = Math.abs(v);                                                                                            // 331
                                                                                                                    // 332
        if (v >= Math.pow(2, 1 - bias)) {                                                                           // 333
          e = Math.min(Math.floor(Math.log(v) / Math.LN2), 1023);                                                   // 334
          f = roundToEven(v / Math.pow(2, e) * Math.pow(2, fbits));                                                 // 335
          if (f / Math.pow(2, fbits) >= 2) {                                                                        // 336
            e = e + 1;                                                                                              // 337
            f = 1;                                                                                                  // 338
          }                                                                                                         // 339
          if (e > bias) {                                                                                           // 340
            // Overflow                                                                                             // 341
            e = (1 << ebits) - 1;                                                                                   // 342
            f = 0;                                                                                                  // 343
          } else {                                                                                                  // 344
            // Normal                                                                                               // 345
            e = e + bias;                                                                                           // 346
            f = f - Math.pow(2, fbits);                                                                             // 347
          }                                                                                                         // 348
        } else {                                                                                                    // 349
          // Subnormal                                                                                              // 350
          e = 0;                                                                                                    // 351
          f = roundToEven(v / Math.pow(2, 1 - bias - fbits));                                                       // 352
        }                                                                                                           // 353
      }                                                                                                             // 354
                                                                                                                    // 355
      // Pack sign, exponent, fraction                                                                              // 356
      bits = [];                                                                                                    // 357
      for (i = fbits; i; i -= 1) {                                                                                  // 358
        bits.push(f % 2 ? 1 : 0);                                                                                   // 359
        f = Math.floor(f / 2);                                                                                      // 360
      }                                                                                                             // 361
      for (i = ebits; i; i -= 1) {                                                                                  // 362
        bits.push(e % 2 ? 1 : 0);                                                                                   // 363
        e = Math.floor(e / 2);                                                                                      // 364
      }                                                                                                             // 365
      bits.push(s ? 1 : 0);                                                                                         // 366
      bits.reverse();                                                                                               // 367
      str = bits.join('');                                                                                          // 368
                                                                                                                    // 369
      // Bits to bytes                                                                                              // 370
      bytes = [];                                                                                                   // 371
      while (str.length) {                                                                                          // 372
        bytes.push(parseInt(str.slice(0, 8), 2));                                                                   // 373
        str = str.slice(8);                                                                                         // 374
      }                                                                                                             // 375
      return bytes;                                                                                                 // 376
    }                                                                                                               // 377
                                                                                                                    // 378
    function unpackIEEE754(bytes, ebits, fbits) {                                                                   // 379
      // Bytes to bits                                                                                              // 380
      var bits = [], i, j, b, str,                                                                                  // 381
          bias, s, e, f;                                                                                            // 382
                                                                                                                    // 383
      for (i = bytes.length; i; i -= 1) {                                                                           // 384
        b = bytes[i - 1];                                                                                           // 385
        for (j = 8; j; j -= 1) {                                                                                    // 386
          bits.push(b % 2 ? 1 : 0);                                                                                 // 387
          b = b >> 1;                                                                                               // 388
        }                                                                                                           // 389
      }                                                                                                             // 390
      bits.reverse();                                                                                               // 391
      str = bits.join('');                                                                                          // 392
                                                                                                                    // 393
      // Unpack sign, exponent, fraction                                                                            // 394
      bias = (1 << (ebits - 1)) - 1;                                                                                // 395
      s = parseInt(str.slice(0, 1), 2) ? -1 : 1;                                                                    // 396
      e = parseInt(str.slice(1, 1 + ebits), 2);                                                                     // 397
      f = parseInt(str.slice(1 + ebits), 2);                                                                        // 398
                                                                                                                    // 399
      // Produce number                                                                                             // 400
      if (e === (1 << ebits) - 1) {                                                                                 // 401
        return f !== 0 ? NaN : s * Infinity;                                                                        // 402
      } else if (e > 0) {                                                                                           // 403
        // Normalized                                                                                               // 404
        return s * Math.pow(2, e - bias) * (1 + f / Math.pow(2, fbits));                                            // 405
      } else if (f !== 0) {                                                                                         // 406
        // Denormalized                                                                                             // 407
        return s * Math.pow(2, -(bias - 1)) * (f / Math.pow(2, fbits));                                             // 408
      } else {                                                                                                      // 409
        return s < 0 ? -0 : 0;                                                                                      // 410
      }                                                                                                             // 411
    }                                                                                                               // 412
                                                                                                                    // 413
    function unpackFloat64(b) { return unpackIEEE754(b, 11, 52); }                                                  // 414
    function packFloat64(v) { return packIEEE754(v, 11, 52); }                                                      // 415
    function unpackFloat32(b) { return unpackIEEE754(b, 8, 23); }                                                   // 416
    function packFloat32(v) { return packIEEE754(v, 8, 23); }                                                       // 417
                                                                                                                    // 418
    var conversions = {                                                                                             // 419
      toFloat32: function (num) { return unpackFloat32(packFloat32(num)); }                                         // 420
    };                                                                                                              // 421
    if (typeof Float32Array !== 'undefined') {                                                                      // 422
      var float32array = new Float32Array(1);                                                                       // 423
      conversions.toFloat32 = function (num) {                                                                      // 424
        float32array[0] = num;                                                                                      // 425
        return float32array[0];                                                                                     // 426
      };                                                                                                            // 427
    }                                                                                                               // 428
    return conversions;                                                                                             // 429
  }());                                                                                                             // 430
                                                                                                                    // 431
  defineProperties(String, {                                                                                        // 432
    fromCodePoint: function fromCodePoint(_) { // length = 1                                                        // 433
      var result = [];                                                                                              // 434
      var next;                                                                                                     // 435
      for (var i = 0, length = arguments.length; i < length; i++) {                                                 // 436
        next = Number(arguments[i]);                                                                                // 437
        if (!ES.SameValue(next, ES.ToInteger(next)) || next < 0 || next > 0x10FFFF) {                               // 438
          throw new RangeError('Invalid code point ' + next);                                                       // 439
        }                                                                                                           // 440
                                                                                                                    // 441
        if (next < 0x10000) {                                                                                       // 442
          result.push(String.fromCharCode(next));                                                                   // 443
        } else {                                                                                                    // 444
          next -= 0x10000;                                                                                          // 445
          result.push(String.fromCharCode((next >> 10) + 0xD800));                                                  // 446
          result.push(String.fromCharCode((next % 0x400) + 0xDC00));                                                // 447
        }                                                                                                           // 448
      }                                                                                                             // 449
      return result.join('');                                                                                       // 450
    },                                                                                                              // 451
                                                                                                                    // 452
    raw: function raw(callSite) { // raw.length===1                                                                 // 453
      var cooked = ES.ToObject(callSite, 'bad callSite');                                                           // 454
      var rawValue = cooked.raw;                                                                                    // 455
      var rawString = ES.ToObject(rawValue, 'bad raw value');                                                       // 456
      var len = rawString.length;                                                                                   // 457
      var literalsegments = ES.ToLength(len);                                                                       // 458
      if (literalsegments <= 0) {                                                                                   // 459
        return '';                                                                                                  // 460
      }                                                                                                             // 461
                                                                                                                    // 462
      var stringElements = [];                                                                                      // 463
      var nextIndex = 0;                                                                                            // 464
      var nextKey, next, nextSeg, nextSub;                                                                          // 465
      while (nextIndex < literalsegments) {                                                                         // 466
        nextKey = String(nextIndex);                                                                                // 467
        next = rawString[nextKey];                                                                                  // 468
        nextSeg = String(next);                                                                                     // 469
        stringElements.push(nextSeg);                                                                               // 470
        if (nextIndex + 1 >= literalsegments) {                                                                     // 471
          break;                                                                                                    // 472
        }                                                                                                           // 473
        next = nextIndex + 1 < arguments.length ? arguments[nextIndex + 1] : '';                                    // 474
        nextSub = String(next);                                                                                     // 475
        stringElements.push(nextSub);                                                                               // 476
        nextIndex++;                                                                                                // 477
      }                                                                                                             // 478
      return stringElements.join('');                                                                               // 479
    }                                                                                                               // 480
  });                                                                                                               // 481
                                                                                                                    // 482
  // Firefox 31 reports this function's length as 0                                                                 // 483
  // https://bugzilla.mozilla.org/show_bug.cgi?id=1062484                                                           // 484
  if (String.fromCodePoint.length !== 1) {                                                                          // 485
    var originalFromCodePoint = Function.apply.bind(String.fromCodePoint);                                          // 486
    defineProperty(String, 'fromCodePoint', function (_) { return originalFromCodePoint(this, arguments); }, true);
  }                                                                                                                 // 488
                                                                                                                    // 489
  var StringShims = {                                                                                               // 490
    // Fast repeat, uses the `Exponentiation by squaring` algorithm.                                                // 491
    // Perf: http://jsperf.com/string-repeat2/2                                                                     // 492
    repeat: (function () {                                                                                          // 493
      var repeat = function (s, times) {                                                                            // 494
        if (times < 1) { return ''; }                                                                               // 495
        if (times % 2) { return repeat(s, times - 1) + s; }                                                         // 496
        var half = repeat(s, times / 2);                                                                            // 497
        return half + half;                                                                                         // 498
      };                                                                                                            // 499
                                                                                                                    // 500
      return function (times) {                                                                                     // 501
        var thisStr = String(ES.CheckObjectCoercible(this));                                                        // 502
        times = ES.ToInteger(times);                                                                                // 503
        if (times < 0 || times === Infinity) {                                                                      // 504
          throw new RangeError('Invalid String#repeat value');                                                      // 505
        }                                                                                                           // 506
        return repeat(thisStr, times);                                                                              // 507
      };                                                                                                            // 508
    })(),                                                                                                           // 509
                                                                                                                    // 510
    startsWith: function (searchStr) {                                                                              // 511
      var thisStr = String(ES.CheckObjectCoercible(this));                                                          // 512
      if (Type.regex(searchStr)) {                                                                                  // 513
        throw new TypeError('Cannot call method "startsWith" with a regex');                                        // 514
      }                                                                                                             // 515
      searchStr = String(searchStr);                                                                                // 516
      var startArg = arguments.length > 1 ? arguments[1] : void 0;                                                  // 517
      var start = Math.max(ES.ToInteger(startArg), 0);                                                              // 518
      return thisStr.slice(start, start + searchStr.length) === searchStr;                                          // 519
    },                                                                                                              // 520
                                                                                                                    // 521
    endsWith: function (searchStr) {                                                                                // 522
      var thisStr = String(ES.CheckObjectCoercible(this));                                                          // 523
      if (Type.regex(searchStr)) {                                                                                  // 524
        throw new TypeError('Cannot call method "endsWith" with a regex');                                          // 525
      }                                                                                                             // 526
      searchStr = String(searchStr);                                                                                // 527
      var thisLen = thisStr.length;                                                                                 // 528
      var posArg = arguments.length > 1 ? arguments[1] : void 0;                                                    // 529
      var pos = typeof posArg === 'undefined' ? thisLen : ES.ToInteger(posArg);                                     // 530
      var end = Math.min(Math.max(pos, 0), thisLen);                                                                // 531
      return thisStr.slice(end - searchStr.length, end) === searchStr;                                              // 532
    },                                                                                                              // 533
                                                                                                                    // 534
    includes: function includes(searchString) {                                                                     // 535
      var position = arguments.length > 1 ? arguments[1] : void 0;                                                  // 536
      // Somehow this trick makes method 100% compat with the spec.                                                 // 537
      return _indexOf(this, searchString, position) !== -1;                                                         // 538
    },                                                                                                              // 539
                                                                                                                    // 540
    codePointAt: function (pos) {                                                                                   // 541
      var thisStr = String(ES.CheckObjectCoercible(this));                                                          // 542
      var position = ES.ToInteger(pos);                                                                             // 543
      var length = thisStr.length;                                                                                  // 544
      if (position < 0 || position >= length) { return; }                                                           // 545
      var first = thisStr.charCodeAt(position);                                                                     // 546
      var isEnd = (position + 1 === length);                                                                        // 547
      if (first < 0xD800 || first > 0xDBFF || isEnd) { return first; }                                              // 548
      var second = thisStr.charCodeAt(position + 1);                                                                // 549
      if (second < 0xDC00 || second > 0xDFFF) { return first; }                                                     // 550
      return ((first - 0xD800) * 1024) + (second - 0xDC00) + 0x10000;                                               // 551
    }                                                                                                               // 552
  };                                                                                                                // 553
  defineProperties(String.prototype, StringShims);                                                                  // 554
                                                                                                                    // 555
  var hasStringTrimBug = '\u0085'.trim().length !== 1;                                                              // 556
  if (hasStringTrimBug) {                                                                                           // 557
    var originalStringTrim = String.prototype.trim;                                                                 // 558
    delete String.prototype.trim;                                                                                   // 559
    // whitespace from: http://es5.github.io/#x15.5.4.20                                                            // 560
    // implementation from https://github.com/es-shims/es5-shim/blob/v3.4.0/es5-shim.js#L1304-L1324                 // 561
    var ws = [                                                                                                      // 562
      '\x09\x0A\x0B\x0C\x0D\x20\xA0\u1680\u180E\u2000\u2001\u2002\u2003',                                           // 563
      '\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028',                                         // 564
      '\u2029\uFEFF'                                                                                                // 565
    ].join('');                                                                                                     // 566
    var trimRegexp = new RegExp('(^[' + ws + ']+)|([' + ws + ']+$)', 'g');                                          // 567
    defineProperties(String.prototype, {                                                                            // 568
      trim: function () {                                                                                           // 569
        if (typeof this === 'undefined' || this === null) {                                                         // 570
          throw new TypeError("can't convert " + this + ' to object');                                              // 571
        }                                                                                                           // 572
        return String(this).replace(trimRegexp, '');                                                                // 573
      }                                                                                                             // 574
    });                                                                                                             // 575
  }                                                                                                                 // 576
                                                                                                                    // 577
  // see https://people.mozilla.org/~jorendorff/es6-draft.html#sec-string.prototype-@@iterator                      // 578
  var StringIterator = function (s) {                                                                               // 579
    this._s = String(ES.CheckObjectCoercible(s));                                                                   // 580
    this._i = 0;                                                                                                    // 581
  };                                                                                                                // 582
  StringIterator.prototype.next = function () {                                                                     // 583
    var s = this._s, i = this._i;                                                                                   // 584
    if (typeof s === 'undefined' || i >= s.length) {                                                                // 585
      this._s = void 0;                                                                                             // 586
      return { value: void 0, done: true };                                                                         // 587
    }                                                                                                               // 588
    var first = s.charCodeAt(i), second, len;                                                                       // 589
    if (first < 0xD800 || first > 0xDBFF || (i + 1) == s.length) {                                                  // 590
      len = 1;                                                                                                      // 591
    } else {                                                                                                        // 592
      second = s.charCodeAt(i + 1);                                                                                 // 593
      len = (second < 0xDC00 || second > 0xDFFF) ? 1 : 2;                                                           // 594
    }                                                                                                               // 595
    this._i = i + len;                                                                                              // 596
    return { value: s.substr(i, len), done: false };                                                                // 597
  };                                                                                                                // 598
  addIterator(StringIterator.prototype);                                                                            // 599
  addIterator(String.prototype, function () {                                                                       // 600
    return new StringIterator(this);                                                                                // 601
  });                                                                                                               // 602
                                                                                                                    // 603
  if (!startsWithIsCompliant) {                                                                                     // 604
    // Firefox has a noncompliant startsWith implementation                                                         // 605
    defineProperties(String.prototype, {                                                                            // 606
      startsWith: StringShims.startsWith,                                                                           // 607
      endsWith: StringShims.endsWith                                                                                // 608
    });                                                                                                             // 609
  }                                                                                                                 // 610
                                                                                                                    // 611
  var ArrayShims = {                                                                                                // 612
    from: function (iterable) {                                                                                     // 613
      var mapFn = arguments.length > 1 ? arguments[1] : void 0;                                                     // 614
                                                                                                                    // 615
      var list = ES.ToObject(iterable, 'bad iterable');                                                             // 616
      if (typeof mapFn !== 'undefined' && !ES.IsCallable(mapFn)) {                                                  // 617
        throw new TypeError('Array.from: when provided, the second argument must be a function');                   // 618
      }                                                                                                             // 619
                                                                                                                    // 620
      var hasThisArg = arguments.length > 2;                                                                        // 621
      var thisArg = hasThisArg ? arguments[2] : void 0;                                                             // 622
                                                                                                                    // 623
      var usingIterator = ES.IsIterable(list);                                                                      // 624
      // does the spec really mean that Arrays should use ArrayIterator?                                            // 625
      // https://bugs.ecmascript.org/show_bug.cgi?id=2416                                                           // 626
      //if (Array.isArray(list)) { usingIterator=false; }                                                           // 627
                                                                                                                    // 628
      var length;                                                                                                   // 629
      var result, i, value;                                                                                         // 630
      if (usingIterator) {                                                                                          // 631
        i = 0;                                                                                                      // 632
        result = ES.IsCallable(this) ? Object(new this()) : [];                                                     // 633
        var it = usingIterator ? ES.GetIterator(list) : null;                                                       // 634
        var iterationValue;                                                                                         // 635
                                                                                                                    // 636
        do {                                                                                                        // 637
          iterationValue = ES.IteratorNext(it);                                                                     // 638
          if (!iterationValue.done) {                                                                               // 639
            value = iterationValue.value;                                                                           // 640
            if (mapFn) {                                                                                            // 641
              result[i] = hasThisArg ? mapFn.call(thisArg, value, i) : mapFn(value, i);                             // 642
            } else {                                                                                                // 643
              result[i] = value;                                                                                    // 644
            }                                                                                                       // 645
            i += 1;                                                                                                 // 646
          }                                                                                                         // 647
        } while (!iterationValue.done);                                                                             // 648
        length = i;                                                                                                 // 649
      } else {                                                                                                      // 650
        length = ES.ToLength(list.length);                                                                          // 651
        result = ES.IsCallable(this) ? Object(new this(length)) : new Array(length);                                // 652
        for (i = 0; i < length; ++i) {                                                                              // 653
          value = list[i];                                                                                          // 654
          if (mapFn) {                                                                                              // 655
            result[i] = hasThisArg ? mapFn.call(thisArg, value, i) : mapFn(value, i);                               // 656
          } else {                                                                                                  // 657
            result[i] = value;                                                                                      // 658
          }                                                                                                         // 659
        }                                                                                                           // 660
      }                                                                                                             // 661
                                                                                                                    // 662
      result.length = length;                                                                                       // 663
      return result;                                                                                                // 664
    },                                                                                                              // 665
                                                                                                                    // 666
    of: function () {                                                                                               // 667
      return Array.from(arguments);                                                                                 // 668
    }                                                                                                               // 669
  };                                                                                                                // 670
  defineProperties(Array, ArrayShims);                                                                              // 671
                                                                                                                    // 672
  var arrayFromSwallowsNegativeLengths = function () {                                                              // 673
    try {                                                                                                           // 674
      return Array.from({ length: -1 }).length === 0;                                                               // 675
    } catch (e) {                                                                                                   // 676
      return false;                                                                                                 // 677
    }                                                                                                               // 678
  };                                                                                                                // 679
  // Fixes a Firefox bug in v32                                                                                     // 680
  // https://bugzilla.mozilla.org/show_bug.cgi?id=1063993                                                           // 681
  if (!arrayFromSwallowsNegativeLengths()) {                                                                        // 682
    defineProperty(Array, 'from', ArrayShims.from, true);                                                           // 683
  }                                                                                                                 // 684
                                                                                                                    // 685
  // Our ArrayIterator is private; see                                                                              // 686
  // https://github.com/paulmillr/es6-shim/issues/252                                                               // 687
  ArrayIterator = function (array, kind) {                                                                          // 688
      this.i = 0;                                                                                                   // 689
      this.array = array;                                                                                           // 690
      this.kind = kind;                                                                                             // 691
  };                                                                                                                // 692
                                                                                                                    // 693
  defineProperties(ArrayIterator.prototype, {                                                                       // 694
    next: function () {                                                                                             // 695
      var i = this.i, array = this.array;                                                                           // 696
      if (!(this instanceof ArrayIterator)) {                                                                       // 697
        throw new TypeError('Not an ArrayIterator');                                                                // 698
      }                                                                                                             // 699
      if (typeof array !== 'undefined') {                                                                           // 700
        var len = ES.ToLength(array.length);                                                                        // 701
        for (; i < len; i++) {                                                                                      // 702
          var kind = this.kind;                                                                                     // 703
          var retval;                                                                                               // 704
          if (kind === 'key') {                                                                                     // 705
            retval = i;                                                                                             // 706
          } else if (kind === 'value') {                                                                            // 707
            retval = array[i];                                                                                      // 708
          } else if (kind === 'entry') {                                                                            // 709
            retval = [i, array[i]];                                                                                 // 710
          }                                                                                                         // 711
          this.i = i + 1;                                                                                           // 712
          return { value: retval, done: false };                                                                    // 713
        }                                                                                                           // 714
      }                                                                                                             // 715
      this.array = void 0;                                                                                          // 716
      return { value: void 0, done: true };                                                                         // 717
    }                                                                                                               // 718
  });                                                                                                               // 719
  addIterator(ArrayIterator.prototype);                                                                             // 720
                                                                                                                    // 721
  var ArrayPrototypeShims = {                                                                                       // 722
    copyWithin: function (target, start) {                                                                          // 723
      var end = arguments[2]; // copyWithin.length must be 2                                                        // 724
      var o = ES.ToObject(this);                                                                                    // 725
      var len = ES.ToLength(o.length);                                                                              // 726
      target = ES.ToInteger(target);                                                                                // 727
      start = ES.ToInteger(start);                                                                                  // 728
      var to = target < 0 ? Math.max(len + target, 0) : Math.min(target, len);                                      // 729
      var from = start < 0 ? Math.max(len + start, 0) : Math.min(start, len);                                       // 730
      end = typeof end === 'undefined' ? len : ES.ToInteger(end);                                                   // 731
      var fin = end < 0 ? Math.max(len + end, 0) : Math.min(end, len);                                              // 732
      var count = Math.min(fin - from, len - to);                                                                   // 733
      var direction = 1;                                                                                            // 734
      if (from < to && to < (from + count)) {                                                                       // 735
        direction = -1;                                                                                             // 736
        from += count - 1;                                                                                          // 737
        to += count - 1;                                                                                            // 738
      }                                                                                                             // 739
      while (count > 0) {                                                                                           // 740
        if (_hasOwnProperty(o, from)) {                                                                             // 741
          o[to] = o[from];                                                                                          // 742
        } else {                                                                                                    // 743
          delete o[from];                                                                                           // 744
        }                                                                                                           // 745
        from += direction;                                                                                          // 746
        to += direction;                                                                                            // 747
        count -= 1;                                                                                                 // 748
      }                                                                                                             // 749
      return o;                                                                                                     // 750
    },                                                                                                              // 751
                                                                                                                    // 752
    fill: function (value) {                                                                                        // 753
      var start = arguments.length > 1 ? arguments[1] : void 0;                                                     // 754
      var end = arguments.length > 2 ? arguments[2] : void 0;                                                       // 755
      var O = ES.ToObject(this);                                                                                    // 756
      var len = ES.ToLength(O.length);                                                                              // 757
      start = ES.ToInteger(typeof start === 'undefined' ? 0 : start);                                               // 758
      end = ES.ToInteger(typeof end === 'undefined' ? len : end);                                                   // 759
                                                                                                                    // 760
      var relativeStart = start < 0 ? Math.max(len + start, 0) : Math.min(start, len);                              // 761
      var relativeEnd = end < 0 ? len + end : end;                                                                  // 762
                                                                                                                    // 763
      for (var i = relativeStart; i < len && i < relativeEnd; ++i) {                                                // 764
        O[i] = value;                                                                                               // 765
      }                                                                                                             // 766
      return O;                                                                                                     // 767
    },                                                                                                              // 768
                                                                                                                    // 769
    find: function find(predicate) {                                                                                // 770
      var list = ES.ToObject(this);                                                                                 // 771
      var length = ES.ToLength(list.length);                                                                        // 772
      if (!ES.IsCallable(predicate)) {                                                                              // 773
        throw new TypeError('Array#find: predicate must be a function');                                            // 774
      }                                                                                                             // 775
      var thisArg = arguments.length > 1 ? arguments[1] : null;                                                     // 776
      for (var i = 0, value; i < length; i++) {                                                                     // 777
        value = list[i];                                                                                            // 778
        if (thisArg) {                                                                                              // 779
          if (predicate.call(thisArg, value, i, list)) { return value; }                                            // 780
        } else {                                                                                                    // 781
          if (predicate(value, i, list)) { return value; }                                                          // 782
        }                                                                                                           // 783
      }                                                                                                             // 784
      return;                                                                                                       // 785
    },                                                                                                              // 786
                                                                                                                    // 787
    findIndex: function findIndex(predicate) {                                                                      // 788
      var list = ES.ToObject(this);                                                                                 // 789
      var length = ES.ToLength(list.length);                                                                        // 790
      if (!ES.IsCallable(predicate)) {                                                                              // 791
        throw new TypeError('Array#findIndex: predicate must be a function');                                       // 792
      }                                                                                                             // 793
      var thisArg = arguments.length > 1 ? arguments[1] : null;                                                     // 794
      for (var i = 0; i < length; i++) {                                                                            // 795
        if (thisArg) {                                                                                              // 796
          if (predicate.call(thisArg, list[i], i, list)) { return i; }                                              // 797
        } else {                                                                                                    // 798
          if (predicate(list[i], i, list)) { return i; }                                                            // 799
        }                                                                                                           // 800
      }                                                                                                             // 801
      return -1;                                                                                                    // 802
    },                                                                                                              // 803
                                                                                                                    // 804
    keys: function () {                                                                                             // 805
      return new ArrayIterator(this, 'key');                                                                        // 806
    },                                                                                                              // 807
                                                                                                                    // 808
    values: function () {                                                                                           // 809
      return new ArrayIterator(this, 'value');                                                                      // 810
    },                                                                                                              // 811
                                                                                                                    // 812
    entries: function () {                                                                                          // 813
      return new ArrayIterator(this, 'entry');                                                                      // 814
    }                                                                                                               // 815
  };                                                                                                                // 816
  // Safari 7.1 defines Array#keys and Array#entries natively,                                                      // 817
  // but the resulting ArrayIterator objects don't have a "next" method.                                            // 818
  if (Array.prototype.keys && !ES.IsCallable([1].keys().next)) {                                                    // 819
    delete Array.prototype.keys;                                                                                    // 820
  }                                                                                                                 // 821
  if (Array.prototype.entries && !ES.IsCallable([1].entries().next)) {                                              // 822
    delete Array.prototype.entries;                                                                                 // 823
  }                                                                                                                 // 824
                                                                                                                    // 825
  // Chrome 38 defines Array#keys and Array#entries, and Array#@@iterator, but not Array#values                     // 826
  if (Array.prototype.keys && Array.prototype.entries && !Array.prototype.values && Array.prototype[$iterator$]) {  // 827
    defineProperties(Array.prototype, {                                                                             // 828
      values: Array.prototype[$iterator$]                                                                           // 829
    });                                                                                                             // 830
    if (Type.symbol(Symbol.unscopables)) {                                                                          // 831
      Array.prototype[Symbol.unscopables].values = true;                                                            // 832
    }                                                                                                               // 833
  }                                                                                                                 // 834
  defineProperties(Array.prototype, ArrayPrototypeShims);                                                           // 835
                                                                                                                    // 836
  addIterator(Array.prototype, function () { return this.values(); });                                              // 837
  // Chrome defines keys/values/entries on Array, but doesn't give us                                               // 838
  // any way to identify its iterator.  So add our own shimmed field.                                               // 839
  if (Object.getPrototypeOf) {                                                                                      // 840
    addIterator(Object.getPrototypeOf([].values()));                                                                // 841
  }                                                                                                                 // 842
                                                                                                                    // 843
  var maxSafeInteger = Math.pow(2, 53) - 1;                                                                         // 844
  defineProperties(Number, {                                                                                        // 845
    MAX_SAFE_INTEGER: maxSafeInteger,                                                                               // 846
    MIN_SAFE_INTEGER: -maxSafeInteger,                                                                              // 847
    EPSILON: 2.220446049250313e-16,                                                                                 // 848
                                                                                                                    // 849
    parseInt: globals.parseInt,                                                                                     // 850
    parseFloat: globals.parseFloat,                                                                                 // 851
                                                                                                                    // 852
    isFinite: function (value) {                                                                                    // 853
      return typeof value === 'number' && global_isFinite(value);                                                   // 854
    },                                                                                                              // 855
                                                                                                                    // 856
    isInteger: function (value) {                                                                                   // 857
      return Number.isFinite(value) &&                                                                              // 858
        ES.ToInteger(value) === value;                                                                              // 859
    },                                                                                                              // 860
                                                                                                                    // 861
    isSafeInteger: function (value) {                                                                               // 862
      return Number.isInteger(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER;                                 // 863
    },                                                                                                              // 864
                                                                                                                    // 865
    isNaN: function (value) {                                                                                       // 866
      // NaN !== NaN, but they are identical.                                                                       // 867
      // NaNs are the only non-reflexive value, i.e., if x !== x,                                                   // 868
      // then x is NaN.                                                                                             // 869
      // isNaN is broken: it converts its argument to number, so                                                    // 870
      // isNaN('foo') => true                                                                                       // 871
      return value !== value;                                                                                       // 872
    }                                                                                                               // 873
  });                                                                                                               // 874
                                                                                                                    // 875
  // Work around bugs in Array#find and Array#findIndex -- early                                                    // 876
  // implementations skipped holes in sparse arrays. (Note that the                                                 // 877
  // implementations of find/findIndex indirectly use shimmed                                                       // 878
  // methods of Number, so this test has to happen down here.)                                                      // 879
  if (![, 1].find(function (item, idx) { return idx === 0; })) {                                                    // 880
    defineProperty(Array.prototype, 'find', ArrayPrototypeShims.find, true);                                        // 881
  }                                                                                                                 // 882
  if ([, 1].findIndex(function (item, idx) { return idx === 0; }) !== 0) {                                          // 883
    defineProperty(Array.prototype, 'findIndex', ArrayPrototypeShims.findIndex, true);                              // 884
  }                                                                                                                 // 885
                                                                                                                    // 886
  if (supportsDescriptors) {                                                                                        // 887
    defineProperties(Object, {                                                                                      // 888
      getPropertyDescriptor: function (subject, name) {                                                             // 889
        var pd = Object.getOwnPropertyDescriptor(subject, name);                                                    // 890
        var proto = Object.getPrototypeOf(subject);                                                                 // 891
        while (typeof pd === 'undefined' && proto !== null) {                                                       // 892
          pd = Object.getOwnPropertyDescriptor(proto, name);                                                        // 893
          proto = Object.getPrototypeOf(proto);                                                                     // 894
        }                                                                                                           // 895
        return pd;                                                                                                  // 896
      },                                                                                                            // 897
                                                                                                                    // 898
      getPropertyNames: function (subject) {                                                                        // 899
        var result = Object.getOwnPropertyNames(subject);                                                           // 900
        var proto = Object.getPrototypeOf(subject);                                                                 // 901
                                                                                                                    // 902
        var addProperty = function (property) {                                                                     // 903
          if (result.indexOf(property) === -1) {                                                                    // 904
            result.push(property);                                                                                  // 905
          }                                                                                                         // 906
        };                                                                                                          // 907
                                                                                                                    // 908
        while (proto !== null) {                                                                                    // 909
          Object.getOwnPropertyNames(proto).forEach(addProperty);                                                   // 910
          proto = Object.getPrototypeOf(proto);                                                                     // 911
        }                                                                                                           // 912
        return result;                                                                                              // 913
      }                                                                                                             // 914
    });                                                                                                             // 915
                                                                                                                    // 916
    defineProperties(Object, {                                                                                      // 917
      // 19.1.3.1                                                                                                   // 918
      assign: function (target, source) {                                                                           // 919
        if (!ES.TypeIsObject(target)) {                                                                             // 920
          throw new TypeError('target must be an object');                                                          // 921
        }                                                                                                           // 922
        return Array.prototype.reduce.call(arguments, function (target, source) {                                   // 923
          return Object.keys(Object(source)).reduce(function (target, key) {                                        // 924
            target[key] = source[key];                                                                              // 925
            return target;                                                                                          // 926
          }, target);                                                                                               // 927
        });                                                                                                         // 928
      },                                                                                                            // 929
                                                                                                                    // 930
      is: function (a, b) {                                                                                         // 931
        return ES.SameValue(a, b);                                                                                  // 932
      },                                                                                                            // 933
                                                                                                                    // 934
      // 19.1.3.9                                                                                                   // 935
      // shim from https://gist.github.com/WebReflection/5593554                                                    // 936
      setPrototypeOf: (function (Object, magic) {                                                                   // 937
        var set;                                                                                                    // 938
                                                                                                                    // 939
        var checkArgs = function (O, proto) {                                                                       // 940
          if (!ES.TypeIsObject(O)) {                                                                                // 941
            throw new TypeError('cannot set prototype on a non-object');                                            // 942
          }                                                                                                         // 943
          if (!(proto === null || ES.TypeIsObject(proto))) {                                                        // 944
            throw new TypeError('can only set prototype to an object or null' + proto);                             // 945
          }                                                                                                         // 946
        };                                                                                                          // 947
                                                                                                                    // 948
        var setPrototypeOf = function (O, proto) {                                                                  // 949
          checkArgs(O, proto);                                                                                      // 950
          set.call(O, proto);                                                                                       // 951
          return O;                                                                                                 // 952
        };                                                                                                          // 953
                                                                                                                    // 954
        try {                                                                                                       // 955
          // this works already in Firefox and Safari                                                               // 956
          set = Object.getOwnPropertyDescriptor(Object.prototype, magic).set;                                       // 957
          set.call({}, null);                                                                                       // 958
        } catch (e) {                                                                                               // 959
          if (Object.prototype !== {}[magic]) {                                                                     // 960
            // IE < 11 cannot be shimmed                                                                            // 961
            return;                                                                                                 // 962
          }                                                                                                         // 963
          // probably Chrome or some old Mobile stock browser                                                       // 964
          set = function (proto) {                                                                                  // 965
            this[magic] = proto;                                                                                    // 966
          };                                                                                                        // 967
          // please note that this will **not** work                                                                // 968
          // in those browsers that do not inherit                                                                  // 969
          // __proto__ by mistake from Object.prototype                                                             // 970
          // in these cases we should probably throw an error                                                       // 971
          // or at least be informed about the issue                                                                // 972
          setPrototypeOf.polyfill = setPrototypeOf(                                                                 // 973
            setPrototypeOf({}, null),                                                                               // 974
            Object.prototype                                                                                        // 975
          ) instanceof Object;                                                                                      // 976
          // setPrototypeOf.polyfill === true means it works as meant                                               // 977
          // setPrototypeOf.polyfill === false means it's not 100% reliable                                         // 978
          // setPrototypeOf.polyfill === undefined                                                                  // 979
          // or                                                                                                     // 980
          // setPrototypeOf.polyfill ==  null means it's not a polyfill                                             // 981
          // which means it works as expected                                                                       // 982
          // we can even delete Object.prototype.__proto__;                                                         // 983
        }                                                                                                           // 984
        return setPrototypeOf;                                                                                      // 985
      })(Object, '__proto__')                                                                                       // 986
    });                                                                                                             // 987
  }                                                                                                                 // 988
                                                                                                                    // 989
  // Workaround bug in Opera 12 where setPrototypeOf(x, null) doesn't work,                                         // 990
  // but Object.create(null) does.                                                                                  // 991
  if (Object.setPrototypeOf && Object.getPrototypeOf &&                                                             // 992
      Object.getPrototypeOf(Object.setPrototypeOf({}, null)) !== null &&                                            // 993
      Object.getPrototypeOf(Object.create(null)) === null) {                                                        // 994
    (function () {                                                                                                  // 995
      var FAKENULL = Object.create(null);                                                                           // 996
      var gpo = Object.getPrototypeOf, spo = Object.setPrototypeOf;                                                 // 997
      Object.getPrototypeOf = function (o) {                                                                        // 998
        var result = gpo(o);                                                                                        // 999
        return result === FAKENULL ? null : result;                                                                 // 1000
      };                                                                                                            // 1001
      Object.setPrototypeOf = function (o, p) {                                                                     // 1002
        if (p === null) { p = FAKENULL; }                                                                           // 1003
        return spo(o, p);                                                                                           // 1004
      };                                                                                                            // 1005
      Object.setPrototypeOf.polyfill = false;                                                                       // 1006
    })();                                                                                                           // 1007
  }                                                                                                                 // 1008
                                                                                                                    // 1009
  try {                                                                                                             // 1010
    Object.keys('foo');                                                                                             // 1011
  } catch (e) {                                                                                                     // 1012
    var originalObjectKeys = Object.keys;                                                                           // 1013
    Object.keys = function (obj) {                                                                                  // 1014
      return originalObjectKeys(ES.ToObject(obj));                                                                  // 1015
    };                                                                                                              // 1016
  }                                                                                                                 // 1017
                                                                                                                    // 1018
  var MathShims = {                                                                                                 // 1019
    acosh: function (value) {                                                                                       // 1020
      value = Number(value);                                                                                        // 1021
      if (Number.isNaN(value) || value < 1) { return NaN; }                                                         // 1022
      if (value === 1) { return 0; }                                                                                // 1023
      if (value === Infinity) { return value; }                                                                     // 1024
      return Math.log(value + Math.sqrt(value * value - 1));                                                        // 1025
    },                                                                                                              // 1026
                                                                                                                    // 1027
    asinh: function (value) {                                                                                       // 1028
      value = Number(value);                                                                                        // 1029
      if (value === 0 || !global_isFinite(value)) {                                                                 // 1030
        return value;                                                                                               // 1031
      }                                                                                                             // 1032
      return value < 0 ? -Math.asinh(-value) : Math.log(value + Math.sqrt(value * value + 1));                      // 1033
    },                                                                                                              // 1034
                                                                                                                    // 1035
    atanh: function (value) {                                                                                       // 1036
      value = Number(value);                                                                                        // 1037
      if (Number.isNaN(value) || value < -1 || value > 1) {                                                         // 1038
        return NaN;                                                                                                 // 1039
      }                                                                                                             // 1040
      if (value === -1) { return -Infinity; }                                                                       // 1041
      if (value === 1) { return Infinity; }                                                                         // 1042
      if (value === 0) { return value; }                                                                            // 1043
      return 0.5 * Math.log((1 + value) / (1 - value));                                                             // 1044
    },                                                                                                              // 1045
                                                                                                                    // 1046
    cbrt: function (value) {                                                                                        // 1047
      value = Number(value);                                                                                        // 1048
      if (value === 0) { return value; }                                                                            // 1049
      var negate = value < 0, result;                                                                               // 1050
      if (negate) { value = -value; }                                                                               // 1051
      result = Math.pow(value, 1 / 3);                                                                              // 1052
      return negate ? -result : result;                                                                             // 1053
    },                                                                                                              // 1054
                                                                                                                    // 1055
    clz32: function (value) {                                                                                       // 1056
      // See https://bugs.ecmascript.org/show_bug.cgi?id=2465                                                       // 1057
      value = Number(value);                                                                                        // 1058
      var number = ES.ToUint32(value);                                                                              // 1059
      if (number === 0) {                                                                                           // 1060
        return 32;                                                                                                  // 1061
      }                                                                                                             // 1062
      return 32 - (number).toString(2).length;                                                                      // 1063
    },                                                                                                              // 1064
                                                                                                                    // 1065
    cosh: function (value) {                                                                                        // 1066
      value = Number(value);                                                                                        // 1067
      if (value === 0) { return 1; } // +0 or -0                                                                    // 1068
      if (Number.isNaN(value)) { return NaN; }                                                                      // 1069
      if (!global_isFinite(value)) { return Infinity; }                                                             // 1070
      if (value < 0) { value = -value; }                                                                            // 1071
      if (value > 21) { return Math.exp(value) / 2; }                                                               // 1072
      return (Math.exp(value) + Math.exp(-value)) / 2;                                                              // 1073
    },                                                                                                              // 1074
                                                                                                                    // 1075
    expm1: function (value) {                                                                                       // 1076
      value = Number(value);                                                                                        // 1077
      if (value === -Infinity) { return -1; }                                                                       // 1078
      if (!global_isFinite(value) || value === 0) { return value; }                                                 // 1079
      return Math.exp(value) - 1;                                                                                   // 1080
    },                                                                                                              // 1081
                                                                                                                    // 1082
    hypot: function (x, y) {                                                                                        // 1083
      var anyNaN = false;                                                                                           // 1084
      var allZero = true;                                                                                           // 1085
      var anyInfinity = false;                                                                                      // 1086
      var numbers = [];                                                                                             // 1087
      Array.prototype.every.call(arguments, function (arg) {                                                        // 1088
        var num = Number(arg);                                                                                      // 1089
        if (Number.isNaN(num)) {                                                                                    // 1090
          anyNaN = true;                                                                                            // 1091
        } else if (num === Infinity || num === -Infinity) {                                                         // 1092
          anyInfinity = true;                                                                                       // 1093
        } else if (num !== 0) {                                                                                     // 1094
          allZero = false;                                                                                          // 1095
        }                                                                                                           // 1096
        if (anyInfinity) {                                                                                          // 1097
          return false;                                                                                             // 1098
        } else if (!anyNaN) {                                                                                       // 1099
          numbers.push(Math.abs(num));                                                                              // 1100
        }                                                                                                           // 1101
        return true;                                                                                                // 1102
      });                                                                                                           // 1103
      if (anyInfinity) { return Infinity; }                                                                         // 1104
      if (anyNaN) { return NaN; }                                                                                   // 1105
      if (allZero) { return 0; }                                                                                    // 1106
                                                                                                                    // 1107
      numbers.sort(function (a, b) { return b - a; });                                                              // 1108
      var largest = numbers[0];                                                                                     // 1109
      var divided = numbers.map(function (number) { return number / largest; });                                    // 1110
      var sum = divided.reduce(function (sum, number) { return sum += number * number; }, 0);                       // 1111
      return largest * Math.sqrt(sum);                                                                              // 1112
    },                                                                                                              // 1113
                                                                                                                    // 1114
    log2: function (value) {                                                                                        // 1115
      return Math.log(value) * Math.LOG2E;                                                                          // 1116
    },                                                                                                              // 1117
                                                                                                                    // 1118
    log10: function (value) {                                                                                       // 1119
      return Math.log(value) * Math.LOG10E;                                                                         // 1120
    },                                                                                                              // 1121
                                                                                                                    // 1122
    log1p: function (value) {                                                                                       // 1123
      value = Number(value);                                                                                        // 1124
      if (value < -1 || Number.isNaN(value)) { return NaN; }                                                        // 1125
      if (value === 0 || value === Infinity) { return value; }                                                      // 1126
      if (value === -1) { return -Infinity; }                                                                       // 1127
      var result = 0;                                                                                               // 1128
      var n = 50;                                                                                                   // 1129
                                                                                                                    // 1130
      if (value < 0 || value > 1) { return Math.log(1 + value); }                                                   // 1131
      for (var i = 1; i < n; i++) {                                                                                 // 1132
        if ((i % 2) === 0) {                                                                                        // 1133
          result -= Math.pow(value, i) / i;                                                                         // 1134
        } else {                                                                                                    // 1135
          result += Math.pow(value, i) / i;                                                                         // 1136
        }                                                                                                           // 1137
      }                                                                                                             // 1138
                                                                                                                    // 1139
      return result;                                                                                                // 1140
    },                                                                                                              // 1141
                                                                                                                    // 1142
    sign: function (value) {                                                                                        // 1143
      var number = +value;                                                                                          // 1144
      if (number === 0) { return number; }                                                                          // 1145
      if (Number.isNaN(number)) { return number; }                                                                  // 1146
      return number < 0 ? -1 : 1;                                                                                   // 1147
    },                                                                                                              // 1148
                                                                                                                    // 1149
    sinh: function (value) {                                                                                        // 1150
      value = Number(value);                                                                                        // 1151
      if (!global_isFinite(value) || value === 0) { return value; }                                                 // 1152
      return (Math.exp(value) - Math.exp(-value)) / 2;                                                              // 1153
    },                                                                                                              // 1154
                                                                                                                    // 1155
    tanh: function (value) {                                                                                        // 1156
      value = Number(value);                                                                                        // 1157
      if (Number.isNaN(value) || value === 0) { return value; }                                                     // 1158
      if (value === Infinity) { return 1; }                                                                         // 1159
      if (value === -Infinity) { return -1; }                                                                       // 1160
      return (Math.exp(value) - Math.exp(-value)) / (Math.exp(value) + Math.exp(-value));                           // 1161
    },                                                                                                              // 1162
                                                                                                                    // 1163
    trunc: function (value) {                                                                                       // 1164
      var number = Number(value);                                                                                   // 1165
      return number < 0 ? -Math.floor(-number) : Math.floor(number);                                                // 1166
    },                                                                                                              // 1167
                                                                                                                    // 1168
    imul: function (x, y) {                                                                                         // 1169
      // taken from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/imul      // 1170
      x = ES.ToUint32(x);                                                                                           // 1171
      y = ES.ToUint32(y);                                                                                           // 1172
      var ah  = (x >>> 16) & 0xffff;                                                                                // 1173
      var al = x & 0xffff;                                                                                          // 1174
      var bh  = (y >>> 16) & 0xffff;                                                                                // 1175
      var bl = y & 0xffff;                                                                                          // 1176
      // the shift by 0 fixes the sign on the high part                                                             // 1177
      // the final |0 converts the unsigned value into a signed value                                               // 1178
      return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0)|0);                                                   // 1179
    },                                                                                                              // 1180
                                                                                                                    // 1181
    fround: function (x) {                                                                                          // 1182
      if (x === 0 || x === Infinity || x === -Infinity || Number.isNaN(x)) {                                        // 1183
        return x;                                                                                                   // 1184
      }                                                                                                             // 1185
      var num = Number(x);                                                                                          // 1186
      return numberConversion.toFloat32(num);                                                                       // 1187
    }                                                                                                               // 1188
  };                                                                                                                // 1189
  defineProperties(Math, MathShims);                                                                                // 1190
                                                                                                                    // 1191
  if (Math.imul(0xffffffff, 5) !== -5) {                                                                            // 1192
    // Safari 6.1, at least, reports "0" for this value                                                             // 1193
    Math.imul = MathShims.imul;                                                                                     // 1194
  }                                                                                                                 // 1195
                                                                                                                    // 1196
  // Promises                                                                                                       // 1197
  // Simplest possible implementation; use a 3rd-party library if you                                               // 1198
  // want the best possible speed and/or long stack traces.                                                         // 1199
  var PromiseShim = (function () {                                                                                  // 1200
                                                                                                                    // 1201
    var Promise, Promise$prototype;                                                                                 // 1202
                                                                                                                    // 1203
    ES.IsPromise = function (promise) {                                                                             // 1204
      if (!ES.TypeIsObject(promise)) {                                                                              // 1205
        return false;                                                                                               // 1206
      }                                                                                                             // 1207
      if (!promise._promiseConstructor) {                                                                           // 1208
        // _promiseConstructor is a bit more unique than _status, so we'll                                          // 1209
        // check that instead of the [[PromiseStatus]] internal field.                                              // 1210
        return false;                                                                                               // 1211
      }                                                                                                             // 1212
      if (typeof promise._status === 'undefined') {                                                                 // 1213
        return false; // uninitialized                                                                              // 1214
      }                                                                                                             // 1215
      return true;                                                                                                  // 1216
    };                                                                                                              // 1217
                                                                                                                    // 1218
    // "PromiseCapability" in the spec is what most promise implementations                                         // 1219
    // call a "deferred".                                                                                           // 1220
    var PromiseCapability = function (C) {                                                                          // 1221
      if (!ES.IsCallable(C)) {                                                                                      // 1222
        throw new TypeError('bad promise constructor');                                                             // 1223
      }                                                                                                             // 1224
      var capability = this;                                                                                        // 1225
      var resolver = function (resolve, reject) {                                                                   // 1226
        capability.resolve = resolve;                                                                               // 1227
        capability.reject = reject;                                                                                 // 1228
      };                                                                                                            // 1229
      capability.promise = ES.Construct(C, [resolver]);                                                             // 1230
      // see https://bugs.ecmascript.org/show_bug.cgi?id=2478                                                       // 1231
      if (!capability.promise._es6construct) {                                                                      // 1232
        throw new TypeError('bad promise constructor');                                                             // 1233
      }                                                                                                             // 1234
      if (!(ES.IsCallable(capability.resolve) &&                                                                    // 1235
            ES.IsCallable(capability.reject))) {                                                                    // 1236
        throw new TypeError('bad promise constructor');                                                             // 1237
      }                                                                                                             // 1238
    };                                                                                                              // 1239
                                                                                                                    // 1240
    // find an appropriate setImmediate-alike                                                                       // 1241
    var setTimeout = globals.setTimeout;                                                                            // 1242
    var makeZeroTimeout;                                                                                            // 1243
    if (typeof window !== 'undefined' && ES.IsCallable(window.postMessage)) {                                       // 1244
      makeZeroTimeout = function () {                                                                               // 1245
        // from http://dbaron.org/log/20100309-faster-timeouts                                                      // 1246
        var timeouts = [];                                                                                          // 1247
        var messageName = 'zero-timeout-message';                                                                   // 1248
        var setZeroTimeout = function (fn) {                                                                        // 1249
          timeouts.push(fn);                                                                                        // 1250
          window.postMessage(messageName, '*');                                                                     // 1251
        };                                                                                                          // 1252
        var handleMessage = function (event) {                                                                      // 1253
          if (event.source == window && event.data == messageName) {                                                // 1254
            event.stopPropagation();                                                                                // 1255
            if (timeouts.length === 0) { return; }                                                                  // 1256
            var fn = timeouts.shift();                                                                              // 1257
            fn();                                                                                                   // 1258
          }                                                                                                         // 1259
        };                                                                                                          // 1260
        window.addEventListener('message', handleMessage, true);                                                    // 1261
        return setZeroTimeout;                                                                                      // 1262
      };                                                                                                            // 1263
    }                                                                                                               // 1264
    var makePromiseAsap = function () {                                                                             // 1265
      // An efficient task-scheduler based on a pre-existing Promise                                                // 1266
      // implementation, which we can use even if we override the                                                   // 1267
      // global Promise below (in order to workaround bugs)                                                         // 1268
      // https://github.com/Raynos/observ-hash/issues/2#issuecomment-35857671                                       // 1269
      var P = globals.Promise;                                                                                      // 1270
      return P && P.resolve && function (task) {                                                                    // 1271
        return P.resolve().then(task);                                                                              // 1272
      };                                                                                                            // 1273
    };                                                                                                              // 1274
    var enqueue = ES.IsCallable(globals.setImmediate) ?                                                             // 1275
      globals.setImmediate.bind(globals) :                                                                          // 1276
      typeof process === 'object' && process.nextTick ? process.nextTick :                                          // 1277
      makePromiseAsap() ||                                                                                          // 1278
      (ES.IsCallable(makeZeroTimeout) ? makeZeroTimeout() :                                                         // 1279
      function (task) { setTimeout(task, 0); }); // fallback                                                        // 1280
                                                                                                                    // 1281
    var triggerPromiseReactions = function (reactions, x) {                                                         // 1282
      reactions.forEach(function (reaction) {                                                                       // 1283
        enqueue(function () {                                                                                       // 1284
          // PromiseReactionTask                                                                                    // 1285
          var handler = reaction.handler;                                                                           // 1286
          var capability = reaction.capability;                                                                     // 1287
          var resolve = capability.resolve;                                                                         // 1288
          var reject = capability.reject;                                                                           // 1289
          try {                                                                                                     // 1290
            var result = handler(x);                                                                                // 1291
            if (result === capability.promise) {                                                                    // 1292
              throw new TypeError('self resolution');                                                               // 1293
            }                                                                                                       // 1294
            var updateResult =                                                                                      // 1295
              updatePromiseFromPotentialThenable(result, capability);                                               // 1296
            if (!updateResult) {                                                                                    // 1297
              resolve(result);                                                                                      // 1298
            }                                                                                                       // 1299
          } catch (e) {                                                                                             // 1300
            reject(e);                                                                                              // 1301
          }                                                                                                         // 1302
        });                                                                                                         // 1303
      });                                                                                                           // 1304
    };                                                                                                              // 1305
                                                                                                                    // 1306
    var updatePromiseFromPotentialThenable = function (x, capability) {                                             // 1307
      if (!ES.TypeIsObject(x)) {                                                                                    // 1308
        return false;                                                                                               // 1309
      }                                                                                                             // 1310
      var resolve = capability.resolve;                                                                             // 1311
      var reject = capability.reject;                                                                               // 1312
      try {                                                                                                         // 1313
        var then = x.then; // only one invocation of accessor                                                       // 1314
        if (!ES.IsCallable(then)) { return false; }                                                                 // 1315
        then.call(x, resolve, reject);                                                                              // 1316
      } catch (e) {                                                                                                 // 1317
        reject(e);                                                                                                  // 1318
      }                                                                                                             // 1319
      return true;                                                                                                  // 1320
    };                                                                                                              // 1321
                                                                                                                    // 1322
    var promiseResolutionHandler = function (promise, onFulfilled, onRejected) {                                    // 1323
      return function (x) {                                                                                         // 1324
        if (x === promise) {                                                                                        // 1325
          return onRejected(new TypeError('self resolution'));                                                      // 1326
        }                                                                                                           // 1327
        var C = promise._promiseConstructor;                                                                        // 1328
        var capability = new PromiseCapability(C);                                                                  // 1329
        var updateResult = updatePromiseFromPotentialThenable(x, capability);                                       // 1330
        if (updateResult) {                                                                                         // 1331
          return capability.promise.then(onFulfilled, onRejected);                                                  // 1332
        } else {                                                                                                    // 1333
          return onFulfilled(x);                                                                                    // 1334
        }                                                                                                           // 1335
      };                                                                                                            // 1336
    };                                                                                                              // 1337
                                                                                                                    // 1338
    Promise = function (resolver) {                                                                                 // 1339
      var promise = this;                                                                                           // 1340
      promise = emulateES6construct(promise);                                                                       // 1341
      if (!promise._promiseConstructor) {                                                                           // 1342
        // we use _promiseConstructor as a stand-in for the internal                                                // 1343
        // [[PromiseStatus]] field; it's a little more unique.                                                      // 1344
        throw new TypeError('bad promise');                                                                         // 1345
      }                                                                                                             // 1346
      if (typeof promise._status !== 'undefined') {                                                                 // 1347
        throw new TypeError('promise already initialized');                                                         // 1348
      }                                                                                                             // 1349
      // see https://bugs.ecmascript.org/show_bug.cgi?id=2482                                                       // 1350
      if (!ES.IsCallable(resolver)) {                                                                               // 1351
        throw new TypeError('not a valid resolver');                                                                // 1352
      }                                                                                                             // 1353
      promise._status = 'unresolved';                                                                               // 1354
      promise._resolveReactions = [];                                                                               // 1355
      promise._rejectReactions = [];                                                                                // 1356
                                                                                                                    // 1357
      var resolve = function (resolution) {                                                                         // 1358
        if (promise._status !== 'unresolved') { return; }                                                           // 1359
        var reactions = promise._resolveReactions;                                                                  // 1360
        promise._result = resolution;                                                                               // 1361
        promise._resolveReactions = void 0;                                                                         // 1362
        promise._rejectReactions = void 0;                                                                          // 1363
        promise._status = 'has-resolution';                                                                         // 1364
        triggerPromiseReactions(reactions, resolution);                                                             // 1365
      };                                                                                                            // 1366
      var reject = function (reason) {                                                                              // 1367
        if (promise._status !== 'unresolved') { return; }                                                           // 1368
        var reactions = promise._rejectReactions;                                                                   // 1369
        promise._result = reason;                                                                                   // 1370
        promise._resolveReactions = void 0;                                                                         // 1371
        promise._rejectReactions = void 0;                                                                          // 1372
        promise._status = 'has-rejection';                                                                          // 1373
        triggerPromiseReactions(reactions, reason);                                                                 // 1374
      };                                                                                                            // 1375
      try {                                                                                                         // 1376
        resolver(resolve, reject);                                                                                  // 1377
      } catch (e) {                                                                                                 // 1378
        reject(e);                                                                                                  // 1379
      }                                                                                                             // 1380
      return promise;                                                                                               // 1381
    };                                                                                                              // 1382
    Promise$prototype = Promise.prototype;                                                                          // 1383
    var _promiseAllResolver = function (index, values, capability, remaining) {                                     // 1384
      var done = false;                                                                                             // 1385
      return function (x) {                                                                                         // 1386
        if (done) { return; } // protect against being called multiple times                                        // 1387
        done = true;                                                                                                // 1388
        values[index] = x;                                                                                          // 1389
        if ((--remaining.count) === 0) {                                                                            // 1390
          var resolve = capability.resolve;                                                                         // 1391
          resolve(values); // call w/ this===undefined                                                              // 1392
        }                                                                                                           // 1393
      };                                                                                                            // 1394
    };                                                                                                              // 1395
                                                                                                                    // 1396
    defineProperties(Promise, {                                                                                     // 1397
      '@@create': function (obj) {                                                                                  // 1398
        var constructor = this;                                                                                     // 1399
        // AllocatePromise                                                                                          // 1400
        // The `obj` parameter is a hack we use for es5                                                             // 1401
        // compatibility.                                                                                           // 1402
        var prototype = constructor.prototype || Promise$prototype;                                                 // 1403
        obj = obj || create(prototype);                                                                             // 1404
        defineProperties(obj, {                                                                                     // 1405
          _status: void 0,                                                                                          // 1406
          _result: void 0,                                                                                          // 1407
          _resolveReactions: void 0,                                                                                // 1408
          _rejectReactions: void 0,                                                                                 // 1409
          _promiseConstructor: void 0                                                                               // 1410
        });                                                                                                         // 1411
        obj._promiseConstructor = constructor;                                                                      // 1412
        return obj;                                                                                                 // 1413
      },                                                                                                            // 1414
                                                                                                                    // 1415
      all: function all(iterable) {                                                                                 // 1416
        var C = this;                                                                                               // 1417
        var capability = new PromiseCapability(C);                                                                  // 1418
        var resolve = capability.resolve;                                                                           // 1419
        var reject = capability.reject;                                                                             // 1420
        try {                                                                                                       // 1421
          if (!ES.IsIterable(iterable)) {                                                                           // 1422
            throw new TypeError('bad iterable');                                                                    // 1423
          }                                                                                                         // 1424
          var it = ES.GetIterator(iterable);                                                                        // 1425
          var values = [], remaining = { count: 1 };                                                                // 1426
          for (var index = 0; ; index++) {                                                                          // 1427
            var next = ES.IteratorNext(it);                                                                         // 1428
            if (next.done) {                                                                                        // 1429
              break;                                                                                                // 1430
            }                                                                                                       // 1431
            var nextPromise = C.resolve(next.value);                                                                // 1432
            var resolveElement = _promiseAllResolver(                                                               // 1433
              index, values, capability, remaining                                                                  // 1434
            );                                                                                                      // 1435
            remaining.count++;                                                                                      // 1436
            nextPromise.then(resolveElement, capability.reject);                                                    // 1437
          }                                                                                                         // 1438
          if ((--remaining.count) === 0) {                                                                          // 1439
            resolve(values); // call w/ this===undefined                                                            // 1440
          }                                                                                                         // 1441
        } catch (e) {                                                                                               // 1442
          reject(e);                                                                                                // 1443
        }                                                                                                           // 1444
        return capability.promise;                                                                                  // 1445
      },                                                                                                            // 1446
                                                                                                                    // 1447
      race: function race(iterable) {                                                                               // 1448
        var C = this;                                                                                               // 1449
        var capability = new PromiseCapability(C);                                                                  // 1450
        var resolve = capability.resolve;                                                                           // 1451
        var reject = capability.reject;                                                                             // 1452
        try {                                                                                                       // 1453
          if (!ES.IsIterable(iterable)) {                                                                           // 1454
            throw new TypeError('bad iterable');                                                                    // 1455
          }                                                                                                         // 1456
          var it = ES.GetIterator(iterable);                                                                        // 1457
          while (true) {                                                                                            // 1458
            var next = ES.IteratorNext(it);                                                                         // 1459
            if (next.done) {                                                                                        // 1460
              // If iterable has no items, resulting promise will never                                             // 1461
              // resolve; see:                                                                                      // 1462
              // https://github.com/domenic/promises-unwrapping/issues/75                                           // 1463
              // https://bugs.ecmascript.org/show_bug.cgi?id=2515                                                   // 1464
              break;                                                                                                // 1465
            }                                                                                                       // 1466
            var nextPromise = C.resolve(next.value);                                                                // 1467
            nextPromise.then(resolve, reject);                                                                      // 1468
          }                                                                                                         // 1469
        } catch (e) {                                                                                               // 1470
          reject(e);                                                                                                // 1471
        }                                                                                                           // 1472
        return capability.promise;                                                                                  // 1473
      },                                                                                                            // 1474
                                                                                                                    // 1475
      reject: function reject(reason) {                                                                             // 1476
        var C = this;                                                                                               // 1477
        var capability = new PromiseCapability(C);                                                                  // 1478
        var rejectPromise = capability.reject;                                                                      // 1479
        rejectPromise(reason); // call with this===undefined                                                        // 1480
        return capability.promise;                                                                                  // 1481
      },                                                                                                            // 1482
                                                                                                                    // 1483
      resolve: function resolve(v) {                                                                                // 1484
        var C = this;                                                                                               // 1485
        if (ES.IsPromise(v)) {                                                                                      // 1486
          var constructor = v._promiseConstructor;                                                                  // 1487
          if (constructor === C) { return v; }                                                                      // 1488
        }                                                                                                           // 1489
        var capability = new PromiseCapability(C);                                                                  // 1490
        var resolvePromise = capability.resolve;                                                                    // 1491
        resolvePromise(v); // call with this===undefined                                                            // 1492
        return capability.promise;                                                                                  // 1493
      }                                                                                                             // 1494
    });                                                                                                             // 1495
                                                                                                                    // 1496
    defineProperties(Promise$prototype, {                                                                           // 1497
      'catch': function (onRejected) {                                                                              // 1498
        return this.then(void 0, onRejected);                                                                       // 1499
      },                                                                                                            // 1500
                                                                                                                    // 1501
      then: function then(onFulfilled, onRejected) {                                                                // 1502
        var promise = this;                                                                                         // 1503
        if (!ES.IsPromise(promise)) { throw new TypeError('not a promise'); }                                       // 1504
        // this.constructor not this._promiseConstructor; see                                                       // 1505
        // https://bugs.ecmascript.org/show_bug.cgi?id=2513                                                         // 1506
        var C = this.constructor;                                                                                   // 1507
        var capability = new PromiseCapability(C);                                                                  // 1508
        if (!ES.IsCallable(onRejected)) {                                                                           // 1509
          onRejected = function (e) { throw e; };                                                                   // 1510
        }                                                                                                           // 1511
        if (!ES.IsCallable(onFulfilled)) {                                                                          // 1512
          onFulfilled = function (x) { return x; };                                                                 // 1513
        }                                                                                                           // 1514
        var resolutionHandler = promiseResolutionHandler(promise, onFulfilled, onRejected);                         // 1515
        var resolveReaction = { capability: capability, handler: resolutionHandler };                               // 1516
        var rejectReaction = { capability: capability, handler: onRejected };                                       // 1517
        switch (promise._status) {                                                                                  // 1518
          case 'unresolved':                                                                                        // 1519
            promise._resolveReactions.push(resolveReaction);                                                        // 1520
            promise._rejectReactions.push(rejectReaction);                                                          // 1521
            break;                                                                                                  // 1522
          case 'has-resolution':                                                                                    // 1523
            triggerPromiseReactions([resolveReaction], promise._result);                                            // 1524
            break;                                                                                                  // 1525
          case 'has-rejection':                                                                                     // 1526
            triggerPromiseReactions([rejectReaction], promise._result);                                             // 1527
            break;                                                                                                  // 1528
          default:                                                                                                  // 1529
            throw new TypeError('unexpected');                                                                      // 1530
        }                                                                                                           // 1531
        return capability.promise;                                                                                  // 1532
      }                                                                                                             // 1533
    });                                                                                                             // 1534
                                                                                                                    // 1535
    return Promise;                                                                                                 // 1536
  }());                                                                                                             // 1537
                                                                                                                    // 1538
  // Chrome's native Promise has extra methods that it shouldn't have. Let's remove them.                           // 1539
  if (globals.Promise) {                                                                                            // 1540
    delete globals.Promise.accept;                                                                                  // 1541
    delete globals.Promise.defer;                                                                                   // 1542
    delete globals.Promise.prototype.chain;                                                                         // 1543
  }                                                                                                                 // 1544
                                                                                                                    // 1545
  // export the Promise constructor.                                                                                // 1546
  defineProperties(globals, { Promise: PromiseShim });                                                              // 1547
  // In Chrome 33 (and thereabouts) Promise is defined, but the                                                     // 1548
  // implementation is buggy in a number of ways.  Let's check subclassing                                          // 1549
  // support to see if we have a buggy implementation.                                                              // 1550
  var promiseSupportsSubclassing = supportsSubclassing(globals.Promise, function (S) {                              // 1551
    return S.resolve(42) instanceof S;                                                                              // 1552
  });                                                                                                               // 1553
  var promiseIgnoresNonFunctionThenCallbacks = (function () {                                                       // 1554
    try {                                                                                                           // 1555
      globals.Promise.reject(42).then(null, 5).then(null, function () {});                                          // 1556
      return true;                                                                                                  // 1557
    } catch (ex) {                                                                                                  // 1558
      return false;                                                                                                 // 1559
    }                                                                                                               // 1560
  }());                                                                                                             // 1561
  var promiseRequiresObjectContext = (function () {                                                                 // 1562
    try { Promise.call(3, function () {}); } catch (e) { return true; }                                             // 1563
    return false;                                                                                                   // 1564
  }());                                                                                                             // 1565
  if (!promiseSupportsSubclassing || !promiseIgnoresNonFunctionThenCallbacks || !promiseRequiresObjectContext) {    // 1566
    /*globals Promise: true */                                                                                      // 1567
    Promise = PromiseShim;                                                                                          // 1568
    /*globals Promise: false */                                                                                     // 1569
    defineProperty(globals, 'Promise', PromiseShim, true);                                                          // 1570
  }                                                                                                                 // 1571
                                                                                                                    // 1572
  // Map and Set require a true ES5 environment                                                                     // 1573
  // Their fast path also requires that the environment preserve                                                    // 1574
  // property insertion order, which is not guaranteed by the spec.                                                 // 1575
  var testOrder = function (a) {                                                                                    // 1576
    var b = Object.keys(a.reduce(function (o, k) {                                                                  // 1577
      o[k] = true;                                                                                                  // 1578
      return o;                                                                                                     // 1579
    }, {}));                                                                                                        // 1580
    return a.join(':') === b.join(':');                                                                             // 1581
  };                                                                                                                // 1582
  var preservesInsertionOrder = testOrder(['z', 'a', 'bb']);                                                        // 1583
  // some engines (eg, Chrome) only preserve insertion order for string keys                                        // 1584
  var preservesNumericInsertionOrder = testOrder(['z', 1, 'a', '3', 2]);                                            // 1585
                                                                                                                    // 1586
  if (supportsDescriptors) {                                                                                        // 1587
                                                                                                                    // 1588
    var fastkey = function fastkey(key) {                                                                           // 1589
      if (!preservesInsertionOrder) {                                                                               // 1590
        return null;                                                                                                // 1591
      }                                                                                                             // 1592
      var type = typeof key;                                                                                        // 1593
      if (type === 'string') {                                                                                      // 1594
        return '$' + key;                                                                                           // 1595
      } else if (type === 'number') {                                                                               // 1596
        // note that -0 will get coerced to "0" when used as a property key                                         // 1597
        if (!preservesNumericInsertionOrder) {                                                                      // 1598
          return 'n' + key;                                                                                         // 1599
        }                                                                                                           // 1600
        return key;                                                                                                 // 1601
      }                                                                                                             // 1602
      return null;                                                                                                  // 1603
    };                                                                                                              // 1604
                                                                                                                    // 1605
    var emptyObject = function emptyObject() {                                                                      // 1606
      // accomodate some older not-quite-ES5 browsers                                                               // 1607
      return Object.create ? Object.create(null) : {};                                                              // 1608
    };                                                                                                              // 1609
                                                                                                                    // 1610
    var collectionShims = {                                                                                         // 1611
      Map: (function () {                                                                                           // 1612
                                                                                                                    // 1613
        var empty = {};                                                                                             // 1614
                                                                                                                    // 1615
        function MapEntry(key, value) {                                                                             // 1616
          this.key = key;                                                                                           // 1617
          this.value = value;                                                                                       // 1618
          this.next = null;                                                                                         // 1619
          this.prev = null;                                                                                         // 1620
        }                                                                                                           // 1621
                                                                                                                    // 1622
        MapEntry.prototype.isRemoved = function () {                                                                // 1623
          return this.key === empty;                                                                                // 1624
        };                                                                                                          // 1625
                                                                                                                    // 1626
        function MapIterator(map, kind) {                                                                           // 1627
          this.head = map._head;                                                                                    // 1628
          this.i = this.head;                                                                                       // 1629
          this.kind = kind;                                                                                         // 1630
        }                                                                                                           // 1631
                                                                                                                    // 1632
        MapIterator.prototype = {                                                                                   // 1633
          next: function () {                                                                                       // 1634
            var i = this.i, kind = this.kind, head = this.head, result;                                             // 1635
            if (typeof this.i === 'undefined') {                                                                    // 1636
              return { value: void 0, done: true };                                                                 // 1637
            }                                                                                                       // 1638
            while (i.isRemoved() && i !== head) {                                                                   // 1639
              // back up off of removed entries                                                                     // 1640
              i = i.prev;                                                                                           // 1641
            }                                                                                                       // 1642
            // advance to next unreturned element.                                                                  // 1643
            while (i.next !== head) {                                                                               // 1644
              i = i.next;                                                                                           // 1645
              if (!i.isRemoved()) {                                                                                 // 1646
                if (kind === 'key') {                                                                               // 1647
                  result = i.key;                                                                                   // 1648
                } else if (kind === 'value') {                                                                      // 1649
                  result = i.value;                                                                                 // 1650
                } else {                                                                                            // 1651
                  result = [i.key, i.value];                                                                        // 1652
                }                                                                                                   // 1653
                this.i = i;                                                                                         // 1654
                return { value: result, done: false };                                                              // 1655
              }                                                                                                     // 1656
            }                                                                                                       // 1657
            // once the iterator is done, it is done forever.                                                       // 1658
            this.i = void 0;                                                                                        // 1659
            return { value: void 0, done: true };                                                                   // 1660
          }                                                                                                         // 1661
        };                                                                                                          // 1662
        addIterator(MapIterator.prototype);                                                                         // 1663
                                                                                                                    // 1664
        function Map(iterable) {                                                                                    // 1665
          var map = this;                                                                                           // 1666
          if (!ES.TypeIsObject(map)) {                                                                              // 1667
            throw new TypeError('Map does not accept arguments when called as a function');                         // 1668
          }                                                                                                         // 1669
          map = emulateES6construct(map);                                                                           // 1670
          if (!map._es6map) {                                                                                       // 1671
            throw new TypeError('bad map');                                                                         // 1672
          }                                                                                                         // 1673
                                                                                                                    // 1674
          var head = new MapEntry(null, null);                                                                      // 1675
          // circular doubly-linked list.                                                                           // 1676
          head.next = head.prev = head;                                                                             // 1677
                                                                                                                    // 1678
          defineProperties(map, {                                                                                   // 1679
            _head: head,                                                                                            // 1680
            _storage: emptyObject(),                                                                                // 1681
            _size: 0                                                                                                // 1682
          });                                                                                                       // 1683
                                                                                                                    // 1684
          // Optionally initialize map from iterable                                                                // 1685
          if (typeof iterable !== 'undefined' && iterable !== null) {                                               // 1686
            var it = ES.GetIterator(iterable);                                                                      // 1687
            var adder = map.set;                                                                                    // 1688
            if (!ES.IsCallable(adder)) { throw new TypeError('bad map'); }                                          // 1689
            while (true) {                                                                                          // 1690
              var next = ES.IteratorNext(it);                                                                       // 1691
              if (next.done) { break; }                                                                             // 1692
              var nextItem = next.value;                                                                            // 1693
              if (!ES.TypeIsObject(nextItem)) {                                                                     // 1694
                throw new TypeError('expected iterable of pairs');                                                  // 1695
              }                                                                                                     // 1696
              adder.call(map, nextItem[0], nextItem[1]);                                                            // 1697
            }                                                                                                       // 1698
          }                                                                                                         // 1699
          return map;                                                                                               // 1700
        }                                                                                                           // 1701
        var Map$prototype = Map.prototype;                                                                          // 1702
        defineProperties(Map, {                                                                                     // 1703
          '@@create': function (obj) {                                                                              // 1704
            var constructor = this;                                                                                 // 1705
            var prototype = constructor.prototype || Map$prototype;                                                 // 1706
            obj = obj || create(prototype);                                                                         // 1707
            defineProperties(obj, { _es6map: true });                                                               // 1708
            return obj;                                                                                             // 1709
          }                                                                                                         // 1710
        });                                                                                                         // 1711
                                                                                                                    // 1712
        Object.defineProperty(Map.prototype, 'size', {                                                              // 1713
          configurable: true,                                                                                       // 1714
          enumerable: false,                                                                                        // 1715
          get: function () {                                                                                        // 1716
            if (typeof this._size === 'undefined') {                                                                // 1717
              throw new TypeError('size method called on incompatible Map');                                        // 1718
            }                                                                                                       // 1719
            return this._size;                                                                                      // 1720
          }                                                                                                         // 1721
        });                                                                                                         // 1722
                                                                                                                    // 1723
        defineProperties(Map.prototype, {                                                                           // 1724
          get: function (key) {                                                                                     // 1725
            var fkey = fastkey(key);                                                                                // 1726
            if (fkey !== null) {                                                                                    // 1727
              // fast O(1) path                                                                                     // 1728
              var entry = this._storage[fkey];                                                                      // 1729
              if (entry) {                                                                                          // 1730
                return entry.value;                                                                                 // 1731
              } else {                                                                                              // 1732
                return;                                                                                             // 1733
              }                                                                                                     // 1734
            }                                                                                                       // 1735
            var head = this._head, i = head;                                                                        // 1736
            while ((i = i.next) !== head) {                                                                         // 1737
              if (ES.SameValueZero(i.key, key)) {                                                                   // 1738
                return i.value;                                                                                     // 1739
              }                                                                                                     // 1740
            }                                                                                                       // 1741
            return;                                                                                                 // 1742
          },                                                                                                        // 1743
                                                                                                                    // 1744
          has: function (key) {                                                                                     // 1745
            var fkey = fastkey(key);                                                                                // 1746
            if (fkey !== null) {                                                                                    // 1747
              // fast O(1) path                                                                                     // 1748
              return typeof this._storage[fkey] !== 'undefined';                                                    // 1749
            }                                                                                                       // 1750
            var head = this._head, i = head;                                                                        // 1751
            while ((i = i.next) !== head) {                                                                         // 1752
              if (ES.SameValueZero(i.key, key)) {                                                                   // 1753
                return true;                                                                                        // 1754
              }                                                                                                     // 1755
            }                                                                                                       // 1756
            return false;                                                                                           // 1757
          },                                                                                                        // 1758
                                                                                                                    // 1759
          set: function (key, value) {                                                                              // 1760
            var head = this._head, i = head, entry;                                                                 // 1761
            var fkey = fastkey(key);                                                                                // 1762
            if (fkey !== null) {                                                                                    // 1763
              // fast O(1) path                                                                                     // 1764
              if (typeof this._storage[fkey] !== 'undefined') {                                                     // 1765
                this._storage[fkey].value = value;                                                                  // 1766
                return this;                                                                                        // 1767
              } else {                                                                                              // 1768
                entry = this._storage[fkey] = new MapEntry(key, value);                                             // 1769
                i = head.prev;                                                                                      // 1770
                // fall through                                                                                     // 1771
              }                                                                                                     // 1772
            }                                                                                                       // 1773
            while ((i = i.next) !== head) {                                                                         // 1774
              if (ES.SameValueZero(i.key, key)) {                                                                   // 1775
                i.value = value;                                                                                    // 1776
                return this;                                                                                        // 1777
              }                                                                                                     // 1778
            }                                                                                                       // 1779
            entry = entry || new MapEntry(key, value);                                                              // 1780
            if (ES.SameValue(-0, key)) {                                                                            // 1781
              entry.key = +0; // coerce -0 to +0 in entry                                                           // 1782
            }                                                                                                       // 1783
            entry.next = this._head;                                                                                // 1784
            entry.prev = this._head.prev;                                                                           // 1785
            entry.prev.next = entry;                                                                                // 1786
            entry.next.prev = entry;                                                                                // 1787
            this._size += 1;                                                                                        // 1788
            return this;                                                                                            // 1789
          },                                                                                                        // 1790
                                                                                                                    // 1791
          'delete': function (key) {                                                                                // 1792
            var head = this._head, i = head;                                                                        // 1793
            var fkey = fastkey(key);                                                                                // 1794
            if (fkey !== null) {                                                                                    // 1795
              // fast O(1) path                                                                                     // 1796
              if (typeof this._storage[fkey] === 'undefined') {                                                     // 1797
                return false;                                                                                       // 1798
              }                                                                                                     // 1799
              i = this._storage[fkey].prev;                                                                         // 1800
              delete this._storage[fkey];                                                                           // 1801
              // fall through                                                                                       // 1802
            }                                                                                                       // 1803
            while ((i = i.next) !== head) {                                                                         // 1804
              if (ES.SameValueZero(i.key, key)) {                                                                   // 1805
                i.key = i.value = empty;                                                                            // 1806
                i.prev.next = i.next;                                                                               // 1807
                i.next.prev = i.prev;                                                                               // 1808
                this._size -= 1;                                                                                    // 1809
                return true;                                                                                        // 1810
              }                                                                                                     // 1811
            }                                                                                                       // 1812
            return false;                                                                                           // 1813
          },                                                                                                        // 1814
                                                                                                                    // 1815
          clear: function () {                                                                                      // 1816
            this._size = 0;                                                                                         // 1817
            this._storage = emptyObject();                                                                          // 1818
            var head = this._head, i = head, p = i.next;                                                            // 1819
            while ((i = p) !== head) {                                                                              // 1820
              i.key = i.value = empty;                                                                              // 1821
              p = i.next;                                                                                           // 1822
              i.next = i.prev = head;                                                                               // 1823
            }                                                                                                       // 1824
            head.next = head.prev = head;                                                                           // 1825
          },                                                                                                        // 1826
                                                                                                                    // 1827
          keys: function () {                                                                                       // 1828
            return new MapIterator(this, 'key');                                                                    // 1829
          },                                                                                                        // 1830
                                                                                                                    // 1831
          values: function () {                                                                                     // 1832
            return new MapIterator(this, 'value');                                                                  // 1833
          },                                                                                                        // 1834
                                                                                                                    // 1835
          entries: function () {                                                                                    // 1836
            return new MapIterator(this, 'key+value');                                                              // 1837
          },                                                                                                        // 1838
                                                                                                                    // 1839
          forEach: function (callback) {                                                                            // 1840
            var context = arguments.length > 1 ? arguments[1] : null;                                               // 1841
            var it = this.entries();                                                                                // 1842
            for (var entry = it.next(); !entry.done; entry = it.next()) {                                           // 1843
              if (context) {                                                                                        // 1844
                callback.call(context, entry.value[1], entry.value[0], this);                                       // 1845
              } else {                                                                                              // 1846
                callback(entry.value[1], entry.value[0], this);                                                     // 1847
              }                                                                                                     // 1848
            }                                                                                                       // 1849
          }                                                                                                         // 1850
        });                                                                                                         // 1851
        addIterator(Map.prototype, function () { return this.entries(); });                                         // 1852
                                                                                                                    // 1853
        return Map;                                                                                                 // 1854
      })(),                                                                                                         // 1855
                                                                                                                    // 1856
      Set: (function () {                                                                                           // 1857
        // Creating a Map is expensive.  To speed up the common case of                                             // 1858
        // Sets containing only string or numeric keys, we use an object                                            // 1859
        // as backing storage and lazily create a full Map only when                                                // 1860
        // required.                                                                                                // 1861
        var SetShim = function Set(iterable) {                                                                      // 1862
          var set = this;                                                                                           // 1863
          if (!ES.TypeIsObject(set)) {                                                                              // 1864
            throw new TypeError('Set does not accept arguments when called as a function');                         // 1865
          }                                                                                                         // 1866
          set = emulateES6construct(set);                                                                           // 1867
          if (!set._es6set) {                                                                                       // 1868
            throw new TypeError('bad set');                                                                         // 1869
          }                                                                                                         // 1870
                                                                                                                    // 1871
          defineProperties(set, {                                                                                   // 1872
            '[[SetData]]': null,                                                                                    // 1873
            _storage: emptyObject()                                                                                 // 1874
          });                                                                                                       // 1875
                                                                                                                    // 1876
          // Optionally initialize map from iterable                                                                // 1877
          if (typeof iterable !== 'undefined' && iterable !== null) {                                               // 1878
            var it = ES.GetIterator(iterable);                                                                      // 1879
            var adder = set.add;                                                                                    // 1880
            if (!ES.IsCallable(adder)) { throw new TypeError('bad set'); }                                          // 1881
            while (true) {                                                                                          // 1882
              var next = ES.IteratorNext(it);                                                                       // 1883
              if (next.done) { break; }                                                                             // 1884
              var nextItem = next.value;                                                                            // 1885
              adder.call(set, nextItem);                                                                            // 1886
            }                                                                                                       // 1887
          }                                                                                                         // 1888
          return set;                                                                                               // 1889
        };                                                                                                          // 1890
        var Set$prototype = SetShim.prototype;                                                                      // 1891
        defineProperties(SetShim, {                                                                                 // 1892
          '@@create': function (obj) {                                                                              // 1893
            var constructor = this;                                                                                 // 1894
            var prototype = constructor.prototype || Set$prototype;                                                 // 1895
            obj = obj || create(prototype);                                                                         // 1896
            defineProperties(obj, { _es6set: true });                                                               // 1897
            return obj;                                                                                             // 1898
          }                                                                                                         // 1899
        });                                                                                                         // 1900
                                                                                                                    // 1901
        // Switch from the object backing storage to a full Map.                                                    // 1902
        var ensureMap = function ensureMap(set) {                                                                   // 1903
          if (!set['[[SetData]]']) {                                                                                // 1904
            var m = set['[[SetData]]'] = new collectionShims.Map();                                                 // 1905
            Object.keys(set._storage).forEach(function (k) {                                                        // 1906
              // fast check for leading '$'                                                                         // 1907
              if (k.charCodeAt(0) === 36) {                                                                         // 1908
                k = k.slice(1);                                                                                     // 1909
              } else if (k.charAt(0) === 'n') {                                                                     // 1910
                k = +k.slice(1);                                                                                    // 1911
              } else {                                                                                              // 1912
                k = +k;                                                                                             // 1913
              }                                                                                                     // 1914
              m.set(k, k);                                                                                          // 1915
            });                                                                                                     // 1916
            set._storage = null; // free old backing storage                                                        // 1917
          }                                                                                                         // 1918
        };                                                                                                          // 1919
                                                                                                                    // 1920
        Object.defineProperty(SetShim.prototype, 'size', {                                                          // 1921
          configurable: true,                                                                                       // 1922
          enumerable: false,                                                                                        // 1923
          get: function () {                                                                                        // 1924
            if (typeof this._storage === 'undefined') {                                                             // 1925
              // https://github.com/paulmillr/es6-shim/issues/176                                                   // 1926
              throw new TypeError('size method called on incompatible Set');                                        // 1927
            }                                                                                                       // 1928
            ensureMap(this);                                                                                        // 1929
            return this['[[SetData]]'].size;                                                                        // 1930
          }                                                                                                         // 1931
        });                                                                                                         // 1932
                                                                                                                    // 1933
        defineProperties(SetShim.prototype, {                                                                       // 1934
          has: function (key) {                                                                                     // 1935
            var fkey;                                                                                               // 1936
            if (this._storage && (fkey = fastkey(key)) !== null) {                                                  // 1937
              return !!this._storage[fkey];                                                                         // 1938
            }                                                                                                       // 1939
            ensureMap(this);                                                                                        // 1940
            return this['[[SetData]]'].has(key);                                                                    // 1941
          },                                                                                                        // 1942
                                                                                                                    // 1943
          add: function (key) {                                                                                     // 1944
            var fkey;                                                                                               // 1945
            if (this._storage && (fkey = fastkey(key)) !== null) {                                                  // 1946
              this._storage[fkey] = true;                                                                           // 1947
              return this;                                                                                          // 1948
            }                                                                                                       // 1949
            ensureMap(this);                                                                                        // 1950
            this['[[SetData]]'].set(key, key);                                                                      // 1951
            return this;                                                                                            // 1952
          },                                                                                                        // 1953
                                                                                                                    // 1954
          'delete': function (key) {                                                                                // 1955
            var fkey;                                                                                               // 1956
            if (this._storage && (fkey = fastkey(key)) !== null) {                                                  // 1957
              var hasFKey = _hasOwnProperty(this._storage, fkey);                                                   // 1958
              return (delete this._storage[fkey]) && hasFKey;                                                       // 1959
            }                                                                                                       // 1960
            ensureMap(this);                                                                                        // 1961
            return this['[[SetData]]']['delete'](key);                                                              // 1962
          },                                                                                                        // 1963
                                                                                                                    // 1964
          clear: function () {                                                                                      // 1965
            if (this._storage) {                                                                                    // 1966
              this._storage = emptyObject();                                                                        // 1967
              return;                                                                                               // 1968
            }                                                                                                       // 1969
            return this['[[SetData]]'].clear();                                                                     // 1970
          },                                                                                                        // 1971
                                                                                                                    // 1972
          values: function () {                                                                                     // 1973
            ensureMap(this);                                                                                        // 1974
            return this['[[SetData]]'].values();                                                                    // 1975
          },                                                                                                        // 1976
                                                                                                                    // 1977
          entries: function () {                                                                                    // 1978
            ensureMap(this);                                                                                        // 1979
            return this['[[SetData]]'].entries();                                                                   // 1980
          },                                                                                                        // 1981
                                                                                                                    // 1982
          forEach: function (callback) {                                                                            // 1983
            var context = arguments.length > 1 ? arguments[1] : null;                                               // 1984
            var entireSet = this;                                                                                   // 1985
            ensureMap(entireSet);                                                                                   // 1986
            this['[[SetData]]'].forEach(function (value, key) {                                                     // 1987
              if (context) {                                                                                        // 1988
                callback.call(context, key, key, entireSet);                                                        // 1989
              } else {                                                                                              // 1990
                callback(key, key, entireSet);                                                                      // 1991
              }                                                                                                     // 1992
            });                                                                                                     // 1993
          }                                                                                                         // 1994
        });                                                                                                         // 1995
        defineProperty(SetShim, 'keys', SetShim.values, true);                                                      // 1996
        addIterator(SetShim.prototype, function () { return this.values(); });                                      // 1997
                                                                                                                    // 1998
        return SetShim;                                                                                             // 1999
      })()                                                                                                          // 2000
    };                                                                                                              // 2001
    defineProperties(globals, collectionShims);                                                                     // 2002
                                                                                                                    // 2003
    if (globals.Map || globals.Set) {                                                                               // 2004
      /*                                                                                                            // 2005
        - In Firefox < 23, Map#size is a function.                                                                  // 2006
        - In all current Firefox, Set#entries/keys/values & Map#clear do not exist                                  // 2007
        - https://bugzilla.mozilla.org/show_bug.cgi?id=869996                                                       // 2008
        - In Firefox 24, Map and Set do not implement forEach                                                       // 2009
        - In Firefox 25 at least, Map and Set are callable without "new"                                            // 2010
      */                                                                                                            // 2011
      if (                                                                                                          // 2012
        typeof globals.Map.prototype.clear !== 'function' ||                                                        // 2013
        new globals.Set().size !== 0 ||                                                                             // 2014
        new globals.Map().size !== 0 ||                                                                             // 2015
        typeof globals.Map.prototype.keys !== 'function' ||                                                         // 2016
        typeof globals.Set.prototype.keys !== 'function' ||                                                         // 2017
        typeof globals.Map.prototype.forEach !== 'function' ||                                                      // 2018
        typeof globals.Set.prototype.forEach !== 'function' ||                                                      // 2019
        isCallableWithoutNew(globals.Map) ||                                                                        // 2020
        isCallableWithoutNew(globals.Set) ||                                                                        // 2021
        !supportsSubclassing(globals.Map, function (M) {                                                            // 2022
          var m = new M([]);                                                                                        // 2023
          // Firefox 32 is ok with the instantiating the subclass but will                                          // 2024
          // throw when the map is used.                                                                            // 2025
          m.set(42, 42);                                                                                            // 2026
          return m instanceof M;                                                                                    // 2027
        })                                                                                                          // 2028
      ) {                                                                                                           // 2029
        globals.Map = collectionShims.Map;                                                                          // 2030
        globals.Set = collectionShims.Set;                                                                          // 2031
      }                                                                                                             // 2032
    }                                                                                                               // 2033
    if (globals.Set.prototype.keys !== globals.Set.prototype.values) {                                              // 2034
      defineProperty(globals.Set.prototype, 'keys', globals.Set.prototype.values, true);                            // 2035
    }                                                                                                               // 2036
    // Shim incomplete iterator implementations.                                                                    // 2037
    addIterator(Object.getPrototypeOf((new globals.Map()).keys()));                                                 // 2038
    addIterator(Object.getPrototypeOf((new globals.Set()).keys()));                                                 // 2039
  }                                                                                                                 // 2040
                                                                                                                    // 2041
  return globals;                                                                                                   // 2042
}));                                                                                                                // 2043
                                                                                                                    // 2044
                                                                                                                    // 2045
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['poorvavyas:es6-shim'] = {};

})();
